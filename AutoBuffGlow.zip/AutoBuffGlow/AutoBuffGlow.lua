--------------------------------------------------
-- INITIALIZATION
--------------------------------------------------

local frame = CreateFrame("Frame")
ABG_DB = ABG_DB or {}

if ABG_DB.soundChoice == nil then
    ABG_DB.soundChoice = 3 -- Alarm
end

local activeGlows = {}
local orbAnims = {}
local trackedSlots = {}
local soundPlayedThisFrame = false

--------------------------------------------------
-- SOUND OPTIONS
--------------------------------------------------

local SOUND_OPTIONS = {
    { name="None", id=nil },
    { name="Click", id=856 },
    { name="Alarm", id=12867 },
    { name="Bell", id=3081 },
    { name="Map Ping", id=3175 },
    { name="Level Up", id=888 },
    { name="Raid Warning", id=8959 },
    { name="Ready Check", id=8960 }
}

--------------------------------------------------
-- CLASS BUFFS
--------------------------------------------------

local CLASS_BUFFS = {

    SHAMAN = {
        shields = {
            "Lightning Shield",
            "Water Shield",
            "Earth Shield"
        },
        weapons = {
            "Rockbiter Weapon",
            "Flametongue Weapon",
            "Windfury Weapon",
            "Frostbrand Weapon"
        }
    },

    DRUID = {
        buffs = {
            "Mark of the Wild",
            "Thorns"
        }
    },

    PRIEST = {
        buffs = {
            "Power Word: Fortitude",
            "Divine Spirit",
            "Inner Fire"
        }
    },

    MAGE = {
        buffs = {
            "Arcane Intellect",
            "Ice Armor",
            "Mage Armor",
            "Frost Armor"
        }
    },

    PALADIN = {
        buffs = {
            "Blessing of Kings",
            "Blessing of Might",
            "Blessing of Wisdom"
        }
    },

    WARLOCK = {
        buffs = {
            "Demon Armor",
            "Demon Skin"
        }
    },

    WARRIOR = {
        buffs = {
            "Battle Shout",
            "Commanding Shout"
        }
    },

    HUNTER = {
        buffs = {
            "Aspect of the Hawk",
            "Aspect of the Monkey",
            "Aspect of the Cheetah"
        }
    }
}

--------------------------------------------------
-- BUFF CHECKS
--------------------------------------------------

local function HasBuff(name)
    for i=1,40 do
        local buff=UnitBuff("player",i)
        if not buff then break end
        if buff==name then return true end
    end
    return false
end

local function HasAnyBuff(group)
    for _,n in ipairs(group) do
        if HasBuff(n) then return true end
    end
    return false
end

local function HasWeaponEnchant()
    local mh,_,_,oh=GetWeaponEnchantInfo()
    return mh or oh
end

--------------------------------------------------
-- SPELL SLOT CACHE
--------------------------------------------------

local SpellSlotCache = {}

local function RebuildSpellCache()
    wipe(SpellSlotCache)

    for slot = 1, 120 do
        local t, id = GetActionInfo(slot)

        if t == "spell" then
            local name = GetSpellInfo(id)

            if name then
                SpellSlotCache[name] = SpellSlotCache[name] or {}
                table.insert(SpellSlotCache[name], slot)
            end
        end
    end
end

--------------------------------------------------
-- BUTTON LOOKUP CACHE
--------------------------------------------------

local ButtonSlotCache = {}

local PREFIXES = {
    "ActionButton",
    "MultiBarBottomLeftButton",
    "MultiBarBottomRightButton",
    "MultiBarRightButton",
    "MultiBarLeftButton"
}

local function RebuildButtonCache()
    wipe(ButtonSlotCache)

    for _, prefix in ipairs(PREFIXES) do
        for i = 1, 12 do

            local btn = _G[prefix .. i]

            if btn and btn.action then

                ButtonSlotCache[btn.action] =
                    ButtonSlotCache[btn.action] or {}

                table.insert(
                    ButtonSlotCache[btn.action],
                    btn
                )
            end
        end
    end
end

local function GetActionButtons(slot)
    return ButtonSlotCache[slot] or {}
end

--------------------------------------------------
-- GLOW CORE
--------------------------------------------------

local function GetPos(p,s)
    local v=p*4
    if v<1 then return -s/2+s*v,s/2
    elseif v<2 then return s/2,s/2-s*(v-1)
    elseif v<3 then return s/2-s*(v-2),-s/2
    else return -s/2,-s/2+s*(v-3) end
end

local function EnsureGlow(btn)
    if btn.__orbs then return end

    btn.__orbs = {}

    for i = 1, 4 do
        local orb = btn:CreateTexture(nil, "OVERLAY")
        orb:SetTexture("Interface\\Cooldown\\star4")
        orb:SetBlendMode("ADD")
        orb:SetSize(16, 16)
        orb:SetAlpha(0)

        orb.trail = {}

        for t = 1, 8 do
            local tr = btn:CreateTexture(nil, "OVERLAY")
            tr:SetTexture("Interface\\Cooldown\\star4")
            tr:SetBlendMode("ADD")
            tr:SetSize(12 + t * 4, 12 + t * 4)
            tr:SetAlpha(0)

            orb.trail[t] = tr
        end

        orb.trailCount = #orb.trail

        btn.__orbs[i] = orb
    end
end

local function StartAnim(btn)
    if orbAnims[btn] then return end

    local t = 0
    local f = CreateFrame("Frame", nil, btn)

    btn.__size = btn.__size or btn:GetWidth()

    f:SetScript("OnUpdate", function(_, e)
        if not activeGlows[btn] then return end

        t = t + e * 0.35

        local s = btn.__size

        for i = 1, 4 do
            local orb = btn.__orbs[i]
            local base = (t + (i - 1) * 0.25) % 1

            local x, y = GetPos(base, s)

            orb:SetPoint("CENTER", btn, "CENTER", x, y)
            orb:SetAlpha(0.4)

            for ti, tr in ipairs(orb.trail) do
                local off = (base - ti * 0.03) % 1
                local tx, ty = GetPos(off, s)

                tr:SetPoint("CENTER", btn, "CENTER", tx, ty)

                local alpha = (1 - (ti / (orb.trailCount + 1))) ^ 2.5
                tr:SetAlpha(alpha * 0.22)
            end
        end
    end)

    orbAnims[btn] = f
end

local function StopAnim(btn)
    local f=orbAnims[btn]
    if f then
        f:SetScript("OnUpdate",nil)
        f:Hide()
        orbAnims[btn]=nil
    end
end

--------------------------------------------------
-- MAIN LOGIC
--------------------------------------------------

local function HandleSpellGlow(spellName,shouldGlow)
    local newSlots = SpellSlotCache[spellName] or {}
    local oldSlots=trackedSlots[spellName] or {}

    local newSet={}
    for _,s in ipairs(newSlots) do newSet[s]=true end

    for _,oldSlot in ipairs(oldSlots) do
        if not newSet[oldSlot] then
            local buttons=GetActionButtons(oldSlot)
            for _,btn in ipairs(buttons) do
                if activeGlows[btn] then
                    if btn.__orbs then
                        for _,orb in ipairs(btn.__orbs) do
                            orb:SetAlpha(0)
                            for _,tr in ipairs(orb.trail) do tr:SetAlpha(0) end
                        end
                    end
                    StopAnim(btn)
                    activeGlows[btn]=nil
                end
            end
        end
    end

    for _,slot in ipairs(newSlots) do
        local buttons=GetActionButtons(slot)

        for _,btn in ipairs(buttons) do
            if shouldGlow then
                if not activeGlows[btn] then
                    EnsureGlow(btn)
                    StartAnim(btn)
                    activeGlows[btn]=true

                    if ABG_DB.enabled and not soundPlayedThisFrame then
                        local s=SOUND_OPTIONS[ABG_DB.soundChoice]
                        if s and s.id then
                            PlaySound(s.id)
                            soundPlayedThisFrame = true
                        end
                    end
                end
            else
                if activeGlows[btn] then
                    if btn.__orbs then
                        for _,orb in ipairs(btn.__orbs) do
                            orb:SetAlpha(0)
                            for _,tr in ipairs(orb.trail) do tr:SetAlpha(0) end
                        end
                    end
                    StopAnim(btn)
                    activeGlows[btn]=nil
                end
            end
        end
    end

    trackedSlots[spellName]=newSlots
end

--------------------------------------------------
-- UPDATE
--------------------------------------------------

local class=select(2,UnitClass("player"))
local data=CLASS_BUFFS[class] or {}

local function UpdateBuffs()
    if data.shields then
        local has=HasAnyBuff(data.shields)
        for _,n in ipairs(data.shields) do
            HandleSpellGlow(n,not has)
        end
    end

    if data.weapons then
        local has=HasWeaponEnchant()
        for _,n in ipairs(data.weapons) do
            HandleSpellGlow(n,not has)
        end
    end

    -- BUFFS (INDIVIDUAL CHECK)
    if data.buffs then
        for _, n in ipairs(data.buffs) do
            local has = HasBuff(n)
            HandleSpellGlow(n, not has)
        end
    end

end

--------------------------------------------------
-- UI STATE HELPER
--------------------------------------------------

local function UpdateSoundUIState(dropdown)
    if ABG_DB.enabled then
        dropdown:SetAlpha(1)
        UIDropDownMenu_EnableDropDown(dropdown)
    else
        dropdown:SetAlpha(0.5)
        UIDropDownMenu_DisableDropDown(dropdown)
    end
end

--------------------------------------------------
-- INIT
--------------------------------------------------

frame:RegisterEvent("PLAYER_LOGIN")
frame:RegisterEvent("ACTIONBAR_SLOT_CHANGED")
frame:RegisterEvent("PLAYER_ENTERING_WORLD")
frame:RegisterEvent("UPDATE_BINDINGS")

frame:SetScript("OnEvent", function(_, event)

    --------------------------------------------------
    -- REBUILD SPELL CACHE
    --------------------------------------------------

    if event ~= "PLAYER_LOGIN" then
        RebuildSpellCache()
        RebuildButtonCache()
        return
    end

    --------------------------------------------------
    -- LOGIN
    --------------------------------------------------

    activeGlows = {}
    trackedSlots = {}
    orbAnims = {}

    if ABG_DB.enabled == nil then
        ABG_DB.enabled = true
    end

    local panel = CreateFrame("Frame")
    panel.name = "AutoBuffGlow"
    InterfaceOptions_AddCategory(panel)

    --------------------------------------------------
    -- ENABLE CHECKBOX
    --------------------------------------------------

    local cb = CreateFrame(
        "CheckButton",
        nil,
        panel,
        "InterfaceOptionsCheckButtonTemplate"
    )

    cb:SetPoint("TOPLEFT", 20, -40)
    cb.Text:SetText("Enable AutoBuffGlow")
    cb:SetChecked(ABG_DB.enabled)

    --------------------------------------------------
    -- SOUND LABEL
    --------------------------------------------------

    local soundLabel =
        panel:CreateFontString(nil, "ARTWORK", "GameFontNormal")

    soundLabel:SetPoint("TOPLEFT", cb, "BOTTOMLEFT", 25, -25)
    soundLabel:SetText("Sound:")

    --------------------------------------------------
    -- DROPDOWN
    --------------------------------------------------

    local dropdown =
        CreateFrame(
            "Frame",
            "ABG_SoundDropdown",
            panel,
            "UIDropDownMenuTemplate"
        )

    dropdown:SetPoint("TOPLEFT", soundLabel, "BOTTOMLEFT", -15, -5)

    UIDropDownMenu_SetWidth(dropdown, 100)

    UIDropDownMenu_Initialize(dropdown, function(self, level)

        for i, s in ipairs(SOUND_OPTIONS) do

            local info = UIDropDownMenu_CreateInfo()

            info.text = s.name

            info.func = function()

                ABG_DB.soundChoice = i

                UIDropDownMenu_SetSelectedID(dropdown, i)

                if s.id then
                    PlaySound(s.id, "SFX")
                end
            end

            info.checked = (ABG_DB.soundChoice == i)

            UIDropDownMenu_AddButton(info, level)
        end
    end)

    UIDropDownMenu_SetSelectedID(
        dropdown,
        ABG_DB.soundChoice or 3
    )

    --------------------------------------------------
    -- MAIN TOGGLE
    --------------------------------------------------

    cb:SetScript("OnClick", function(self)

        ABG_DB.enabled = self:GetChecked()

        if ABG_DB.enabled then
            PlaySound(856)
        else
            PlaySound(857)
        end

        UpdateSoundUIState(dropdown)

        for btn in pairs(activeGlows) do

            if btn.__orbs then

                for _, orb in ipairs(btn.__orbs) do

                    orb:SetAlpha(0)

                    for _, tr in ipairs(orb.trail) do
                        tr:SetAlpha(0)
                    end
                end
            end

            StopAnim(btn)
        end

        activeGlows = {}
    end)

    --------------------------------------------------
    -- INITIAL STATE
    --------------------------------------------------

    UpdateSoundUIState(dropdown)

    --------------------------------------------------
    -- BUILD CACHE
    --------------------------------------------------
    
    RebuildSpellCache()
    RebuildButtonCache()

    --------------------------------------------------
    -- UPDATE LOOP (THROTTLED)
    --------------------------------------------------

    local elapsed = 0

    frame:SetScript("OnUpdate", function(_, e)

        if not ABG_DB.enabled then
            return
        end

        elapsed = elapsed + e

        if elapsed < 0.25 then
            return
        end

        elapsed = 0

        soundPlayedThisFrame = false
        UpdateBuffs()
    end)

end)