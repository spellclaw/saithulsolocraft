local CachedButtons = {}
local ButtonsCached = false

--------------------------------------------------
-- Gray Value Helper
--------------------------------------------------

local CachedGrayValue = 0

local function RecalculateGrayValue()

    CachedGrayValue = 0

    for bag = 0, NUM_BAG_SLOTS do
        for slot = 1, GetContainerNumSlots(bag) do

            local itemLink =
                GetContainerItemLink(bag, slot)

            if itemLink then

                local _, itemCount =
                    GetContainerItemInfo(bag, slot)

                local _, _, quality,
                      _, _, _, _, _, _, _,
                      vendorPrice =
                    GetItemInfo(itemLink)

                if quality == 0
                   and vendorPrice
                   and vendorPrice > 0 then

                    CachedGrayValue =
                        CachedGrayValue +
                        (vendorPrice * (itemCount or 1))

                end
            end
        end
    end
end

--------------------------------------------------
-- Calculate Gray Value
--------------------------------------------------

local function GetGrayValue()
    return CachedGrayValue
end

--------------------------------------------------
-- Tooltip
--------------------------------------------------

local function UpdateButtonTooltip()

    if not AutoGraySellButton then
        return
    end

    if not GameTooltip:IsOwned(AutoGraySellButton) then
        return
    end

    local value = GetGrayValue()

    GameTooltip:ClearLines()

    GameTooltip:AddLine("AutoGraySell", 1, 0.82, 0)

    GameTooltip:AddDoubleLine(
        "Total Grays Value:",
        GetCoinTextureString(value),
        1, 1, 1,
        1, 1, 1
    )

    if value == 0 then
        GameTooltip:AddLine(
            "No gray items to sell.",
            0.7, 0.7, 0.7
        )
    end

    GameTooltip:Show()
end

--------------------------------------------------
-- Bag Button Cache Helper
--------------------------------------------------

local function CacheBagButtons()

    wipe(CachedButtons)

    for name, button in pairs(_G) do

        if type(name) == "string"
        and type(button) == "table"
        and button.GetObjectType then

            local ok, objectType =
                pcall(
                    button.GetObjectType,
                    button
                )

            if ok
            and objectType == "Button"
            and (
                name:find("^ContainerFrame%d+Item%d+$")
                or
                name:find("^ContainerFrameItem%d+$")
            ) then

                table.insert(
                    CachedButtons,
                    button
                )

            end

        end

    end

    ButtonsCached = true

end

--------------------------------------------------
-- Gray Preview Helper
--------------------------------------------------

local function UpdateGrayPreview(show)

    ShowGrayPreview = show

    if not ButtonsCached then
        CacheBagButtons()
    end

    for _, button in ipairs(CachedButtons) do

        local parent =
            button:GetParent()

        if parent then

            local bag =
                parent:GetID()

            local slot =
                button:GetID()

            if bag ~= nil
            and slot then

                local itemLink =
                    GetContainerItemLink(
                        bag,
                        slot
                    )

                if not button.AGSGrayHighlight then

                    local highlight =
                        button:CreateTexture(
                            nil,
                            "OVERLAY"
                        )

                    highlight:SetAllPoints()

                    highlight:SetTexture(
                        "Interface\\Buttons\\CheckButtonHilight"
                    )

                    highlight:SetBlendMode(
                        "BLEND"
                    )

                    highlight:SetVertexColor(
                        0.55,
                        0.60,
                        0.70
                    )

                    highlight:SetAlpha(
                        0.75
                    )

                    highlight:Hide()

                    button.AGSGrayHighlight =
                        highlight

                end

                local highlight =
                    button.AGSGrayHighlight

                if show
                and itemLink then

                    local _, _, quality,
                          _, _, _, _, _, _, _,
                          vendorPrice =
                        GetItemInfo(itemLink)

                    if quality == 0
                    and vendorPrice
                    and vendorPrice > 0 then

                        highlight:Show()

                    else

                        highlight:Hide()

                    end

                else

                    highlight:Hide()

                end

            end

        end

    end

end

--------------------------------------------------
-- Reliable Delayed Selling
--------------------------------------------------

local sellFrame = CreateFrame("Frame")

local sellTimer = 0
local actualSoldValue = 0

local function FindNextGrayItem()

    for bag = 0, NUM_BAG_SLOTS do
        for slot = 1, GetContainerNumSlots(bag) do

            local itemLink = GetContainerItemLink(bag, slot)

            if itemLink then

                local itemID =
                    tonumber(
                        string.match(
                            itemLink,
                            "item:(%d+)"
                        )
                    )

                local _, itemCount =
                    GetContainerItemInfo(bag, slot)

                local _, _, quality, _, _, _, _, _, _, _, vendorPrice =
                    GetItemInfo(itemLink)

                if quality == 0
                and vendorPrice
                and vendorPrice > 0 then

                    return bag,
                        slot,
                        itemID,
                        vendorPrice * (itemCount or 1)

                end
            end
        end
    end

    return nil
end

local function ProcessSelling(self, elapsed)

    sellTimer = sellTimer + elapsed

    if sellTimer < 0.50 then
        return
    end

    sellTimer = 0

    local bag,
        slot,
        itemID,
        value =
        FindNextGrayItem()

    if not bag then

        sellFrame:SetScript("OnUpdate", nil)

        if actualSoldValue > 0 then

            print(
                "|cff9d9d9dAutoGraySell:|r Sold grays for " ..
                GetCoinTextureString(actualSoldValue)
            )

            actualSoldValue = 0

        else
            print(
                "|cff9d9d9dAutoGraySell:|r No gray items found."
            )
        end

        GameTooltip:Hide()

        return
    end

    actualSoldValue =
        actualSoldValue + value

    UseContainerItem(bag, slot)
end

local function SellGrays()

    if sellFrame:GetScript("OnUpdate") then
        return
    end

    UpdateGrayPreview(false)

    actualSoldValue = 0
    sellTimer = 0

    if PlaySound then

            PlaySound(1115) --BUTTON_CLICK_SOUND

    end

    sellFrame:SetScript(
        "OnUpdate",
        ProcessSelling
    )
end

--------------------------------------------------
-- Button Visibility
--------------------------------------------------

local function UpdateButtonState()

    if not AutoGraySellButton then
        return
    end

    local value = GetGrayValue()

    if value > 0 then
        AutoGraySellButton:Enable()
        AutoGraySellButton:SetAlpha(1.0)
    else
        AutoGraySellButton:Disable()
        AutoGraySellButton:SetAlpha(0.5)
    end

end

local function ShowButton()

    if AutoGraySellButton then
        AutoGraySellButton:Show()
        UpdateButtonState()
    end

end

local function HideButton()

    if AutoGraySellButton then
        AutoGraySellButton:Hide()
    end

end

--------------------------------------------------
-- Merchant Button
--------------------------------------------------

local function CreateMerchantButton()

    if AutoGraySellButton then
        return
    end

    local button = CreateFrame(
        "Button",
        "AutoGraySellButton",
        MerchantFrame,
        "UIPanelButtonTemplate"
    )

    button:SetSize(80, 22)
    button:SetText("Sell Grays")

    button:SetPoint(
        "BOTTOMLEFT",
        MerchantFrame,
        "BOTTOMLEFT",
        80,
        6
    )

    button:SetScript("OnClick", SellGrays)

    button:SetScript("OnEnter", function(self)

        UpdateGrayPreview(true)

        GameTooltip:SetOwner(
            self,
            "ANCHOR_TOP"
        )

        UpdateButtonTooltip()

    end)

    button:SetScript("OnLeave", function()

        UpdateGrayPreview(false)

        GameTooltip:Hide()

    end)

    UpdateButtonState()

end

--------------------------------------------------
-- Merchant Tabs
--------------------------------------------------

local tabsHooked = false

local function HookMerchantTabs()

    if tabsHooked then
        return
    end

    tabsHooked = true

    if MerchantFrameTab1 then
        MerchantFrameTab1:HookScript(
            "OnClick",
            ShowButton
        )
    end

    if MerchantFrameTab2 then
        MerchantFrameTab2:HookScript(
            "OnClick",
            HideButton
        )
    end
end

--------------------------------------------------
-- Events
--------------------------------------------------

local frame = CreateFrame("Frame")

frame:RegisterEvent("MERCHANT_SHOW")
frame:RegisterEvent("BAG_UPDATE")
frame:RegisterEvent("MERCHANT_CLOSED")

frame:SetScript("OnEvent", function(self, event)

    if event == "MERCHANT_SHOW" then

        RecalculateGrayValue()

        CreateMerchantButton()
        HookMerchantTabs()
        UpdateButtonState()
        ShowButton()

    elseif event == "MERCHANT_CLOSED" then

        UpdateGrayPreview(false)

        if sellFrame:GetScript("OnUpdate")
        and actualSoldValue > 0 then

            print(
                "|cff9d9d9dAutoGraySell:|r Sold grays for " ..
                GetCoinTextureString(actualSoldValue)
            )

            actualSoldValue = 0

        end

        sellFrame:SetScript(
            "OnUpdate",
            nil
        )

        sellTimer = 0       

    elseif event == "BAG_UPDATE" then

        ButtonsCached = false

        RecalculateGrayValue()

        if AutoGraySellButton
        and GameTooltip:IsOwned(AutoGraySellButton) then

            UpdateGrayPreview(true)

        end

        UpdateButtonState()

        if AutoGraySellButton
        and GameTooltip:IsOwned(AutoGraySellButton) then

            UpdateButtonTooltip()

        end

    end

end)