local f = CreateFrame("Frame")

local lastLink
local lastText

local function UpdateVendorValue(tooltip)
    if not tooltip:IsShown() then
        lastLink = nil
        lastText = nil
        return
    end

    local _, link = tooltip:GetItem()
    if not link then
        return
    end

    local _, _, _, _, _, _, _, _, _, _, sellPrice = GetItemInfo(link)

    if not sellPrice or sellPrice <= 0 then
        return
    end

    local count = 1

    local button = GetMouseFocus()

    if button and button.GetName then
        local name = button:GetName()

        if name and string.find(name, "^ContainerFrame") then
            local parent = button:GetParent()

            if parent and parent.GetID then
                local bag = parent:GetID()
                local slot = button:GetID()

                local slotLink = GetContainerItemLink(bag, slot)

                if slotLink and slotLink == link then
                    local _, itemCount = GetContainerItemInfo(bag, slot)

                    if itemCount and itemCount > 0 then
                        count = itemCount
                    end
                end
            end
        end
    end

    local vendorText

    if count > 1 and IsShiftKeyDown() then
        vendorText = "Vendor: " .. GetCoinTextureString(sellPrice) .. " (1x)"
    elseif count > 1 then
        vendorText = "Vendor: " .. GetCoinTextureString(sellPrice * count) .. " (" .. count .. "x)"
    else
        vendorText = "Vendor: " .. GetCoinTextureString(sellPrice)
    end

    -- Find an existing Vendor line and update it
    for i = 2, tooltip:NumLines() do
        local prefix = tooltip:GetName() .. "TextLeft"
        local line = _G[prefix .. i]

        if line and line:GetText() and string.find(line:GetText(), "^Vendor:") then
            line:SetText(vendorText)
            line:SetTextColor(1, 1, 1)
            return
        end
    end

    -- Add only one vendor line
    tooltip:AddLine(vendorText, 1, 1, 1)
    tooltip:Show()
end

local tooltips = {
    GameTooltip,
    ItemRefTooltip,
    ShoppingTooltip1,
    ShoppingTooltip2,
    ItemRefShoppingTooltip1,
    ItemRefShoppingTooltip2,
}

f:SetScript("OnUpdate", function()
    for _, tooltip in ipairs(tooltips) do
        if tooltip and tooltip:IsShown() then
            UpdateVendorValue(tooltip)
        end
    end
end)

local shiftDown

local shiftFrame = CreateFrame("Frame")

shiftFrame:SetScript("OnUpdate", function()

    local current = IsShiftKeyDown()

    -- Shift pressed
    if not shiftDown and current then
        if GameTooltip:IsShown() and GameTooltip:GetItem() then
            GameTooltip_ShowCompareItem()
        end
    end

    -- Shift released
    if shiftDown and not current then
        if ShoppingTooltip1 then
            ShoppingTooltip1:Hide()
        end

        if ShoppingTooltip2 then
            ShoppingTooltip2:Hide()
        end
    end

    shiftDown = current
end)