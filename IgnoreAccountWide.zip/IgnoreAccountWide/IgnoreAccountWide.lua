local addon = CreateFrame("Frame")

IgnoreAccountWideDB = IgnoreAccountWideDB or {}

local syncing = false
local loginSyncComplete = false
local lastIgnoreSet = {}

--------------------------------------------------
-- Compatibility
--------------------------------------------------

local function AddIgnoreCompat(name)
    if C_FriendList and C_FriendList.AddIgnore then
        C_FriendList.AddIgnore(name)
    elseif AddIgnore then
        AddIgnore(name)
    end
end

local function DelIgnoreCompat(name)
    if C_FriendList and C_FriendList.DelIgnore then
        C_FriendList.DelIgnore(name)
    elseif DelIgnore then
        DelIgnore(name)
    end
end

local function GetIgnoreCount()
    if C_FriendList and C_FriendList.GetNumIgnores then
        return C_FriendList.GetNumIgnores()
    elseif GetNumIgnores then
        return GetNumIgnores()
    end

    return 0
end

local function GetIgnoreNameAt(index)
    if C_FriendList and C_FriendList.GetIgnoreName then
        return C_FriendList.GetIgnoreName(index)
    elseif GetIgnoreName then
        return GetIgnoreName(index)
    end

    return nil
end

--------------------------------------------------
-- Utilities
--------------------------------------------------

local function NormalizeName(name)
    if not name or name == "" then
        return nil
    end

    if Ambiguate then
        name = Ambiguate(name, "none")
    end

    if strtrim then
        name = strtrim(name)
    end

    return name
end

local function CopySet(src)
    local dst = {}

    for k in pairs(src) do
        dst[k] = true
    end

    return dst
end

local function BuildIgnoreSet()
    local set = {}

    for i = 1, GetIgnoreCount() do
        local name = NormalizeName(GetIgnoreNameAt(i))

        if name then
            set[name] = true
        end
    end

    return set
end

--------------------------------------------------
-- Character -> Database
--------------------------------------------------

local function HandleIgnoreListChanged()
    local current = BuildIgnoreSet()

    for name in pairs(current) do
        if not lastIgnoreSet[name] then
            name = NormalizeName(name)
            IgnoreAccountWideDB[name] = true
        end
    end

    for name in pairs(lastIgnoreSet) do
        if not current[name] then
            name = NormalizeName(name)
            IgnoreAccountWideDB[name] = nil
        end
    end

    lastIgnoreSet = CopySet(current)
end

--------------------------------------------------
-- Database -> Character
--------------------------------------------------

local function SyncCharacterToDatabase()
    local current = BuildIgnoreSet()

    -- Remove names not in DB
    for name in pairs(current) do
        if not IgnoreAccountWideDB[name] then
            DelIgnoreCompat(name)
        end
    end

    current = BuildIgnoreSet()

    -- Add names missing from character
    for name in pairs(IgnoreAccountWideDB) do
        if not current[name] then
            AddIgnoreCompat(name)
        end
    end

    lastIgnoreSet = BuildIgnoreSet()
end

--------------------------------------------------
-- Events
--------------------------------------------------

addon:SetScript("OnEvent", function(_, event)

    if event == "PLAYER_LOGIN" then

        IgnoreAccountWideDB = IgnoreAccountWideDB or {}

        syncing = true

        C_Timer.After(2, function()

            SyncCharacterToDatabase()

            lastIgnoreSet = BuildIgnoreSet()

            loginSyncComplete = true
            syncing = false

        end)

    elseif event == "IGNORELIST_UPDATE" then

        if syncing then
            return
        end

        if not loginSyncComplete then
            return
        end

        HandleIgnoreListChanged()
    end
end)

addon:RegisterEvent("PLAYER_LOGIN")
addon:RegisterEvent("IGNORELIST_UPDATE")