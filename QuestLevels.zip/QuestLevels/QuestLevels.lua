local GetQuestLogTitle = GetQuestLogTitle
local FauxScrollFrame_GetOffset = FauxScrollFrame_GetOffset

local function QuestLevels_Update()
    local offset = FauxScrollFrame_GetOffset(QuestLogListScrollFrame)

    for i = 1, QUESTS_DISPLAYED do
        local button = _G["QuestLogTitle"..i]

        if button then
            if not button.QuestLevelLabel then
                button.QuestLevelLabel =
                    button:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")

                button.QuestLevelLabel:SetWidth(24)
                button.QuestLevelLabel:SetJustifyH("RIGHT")

                button.QuestLevelLabel:SetPoint(
                    "LEFT",
                    button,
                    "LEFT",
                    -3,
                    -1
                )
            end

            local questIndex = offset + i

            local title, level, _, isHeader =
                GetQuestLogTitle(questIndex)

            if title and not isHeader and level and level > 0 then
                local label = button.QuestLevelLabel

                if label:GetText() ~= tostring(level) then
                    label:SetText(level)
                end

                if not label:IsShown() then
                    label:Show()
                end
            else
                if button.QuestLevelLabel:IsShown() then
                    button.QuestLevelLabel:Hide()
                end
            end
        end
    end
end

hooksecurefunc("QuestLog_Update", QuestLevels_Update)

local f = CreateFrame("Frame")
f:RegisterEvent("PLAYER_ENTERING_WORLD")
f:RegisterEvent("QUEST_LOG_UPDATE")
f:SetScript("OnEvent", QuestLevels_Update)