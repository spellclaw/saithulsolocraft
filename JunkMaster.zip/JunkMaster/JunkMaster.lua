local ADDON = ...

--------------------------------------------------
-- Forward Declarations
--------------------------------------------------

local JM = CreateFrame("Frame")

local ScanBagButtons
local UpdateMerchantButton
local SellButton
local IsBuybackTabSelected
local GetMarkedItemValue
local IsItemMarked

local UsingBagnon = IsAddOnLoaded("Bagnon")

JunkMasterDB =
    JunkMasterDB or {}

JunkMasterDB.items =
    JunkMasterDB.items or {}

--------------------------------------------------
-- Utils
--------------------------------------------------

local function GetItemIDFromLink(link)

    if not link then
        return nil
    end

    return tonumber(
        string.match(
            link,
            "item:(%d+)"
        )
    )

end

local VendorPriceCache = {}

local CurrentMarkedValue = 0

local function GetVendorPrice(
    itemID
)

    if not itemID then
        return 0
    end

    local cached =
        VendorPriceCache[itemID]

    if cached ~= nil then

        return cached

    end

    local value =
        select(
            11,
            GetItemInfo(itemID)
        ) or 0

    VendorPriceCache[itemID] =
        value

    return value

end

local function RecalculateMarkedValue()

    CurrentMarkedValue = 0

    for bag = 0, 4 do

        local numSlots =
            GetContainerNumSlots(bag)

        for slot = 1, numSlots do

            local link =
                GetContainerItemLink(
                    bag,
                    slot
                )

            local itemID =
                GetItemIDFromLink(link)

            if itemID
            and IsItemMarked(itemID) then

                local texture,
                      itemCount =
                    GetContainerItemInfo(
                        bag,
                        slot
                    )

                CurrentMarkedValue =
                    CurrentMarkedValue +
                    (
                        GetVendorPrice(
                            itemID
                        )
                        *
                        (
                            itemCount
                            or 1
                        )
                    )

            end

        end

    end

end

IsItemMarked = function(itemID)

    return
        itemID
        and JunkMasterDB.items[itemID]

end

local function SetMarked(itemID, state)

    if not itemID then
        return
    end

    JunkMasterDB.items[itemID] =
        state or nil

end

local function Print(msg)

    DEFAULT_CHAT_FRAME:AddMessage(
        "|cffb87333JunkMaster:|r " ..
        tostring(msg)
    )

end

local function SafeGetButtonInfo(button)

    if not button then
        return nil
    end

    if button.GetInfo then

        local ok, info =
            pcall(
                button.GetInfo,
                button
            )

        if ok
        and type(info) == "table" then

            return info

        end

    end

    if type(button.info) == "table" then
        return button.info
    end

    return nil

end

--------------------------------------------------
-- Sounds
--------------------------------------------------

local function PlayToggleSound(enabled)

    if not PlaySound then
        return
    end

    if enabled then

        PlaySound(856)

    else

        PlaySound(857)

    end

end

--------------------------------------------------
-- Bag Item Helpers
--------------------------------------------------

local function GetButtonItemID(button)

    if not button then
        return nil
    end

    -- Bagnon
    local info =
        SafeGetButtonInfo(button)

    if info then

        return
            info.itemID
            or info.id

    end

    -- Blizzard bags
    local bag =
        button:GetParent()
        and button:GetParent():GetID()

    local slot =
        button:GetID()

    if bag ~= nil
    and slot then

        local link =
            GetContainerItemLink(
                bag,
                slot
            )

        return
            GetItemIDFromLink(link)

    end

    return nil

end

--------------------------------------------------
-- Overlay Update
--------------------------------------------------

local function UpdateSlotVisual(button)

    if not button then
        return
    end

    local itemID =
        GetButtonItemID(button)

    if not button.JMTrashIcon then

        local icon =
            CreateFrame(
                "Button",
                nil,
                button
            )

        icon:SetParent(button)

        icon:SetWidth(14)
        icon:SetHeight(14)

        icon:ClearAllPoints()

        icon:SetPoint(
            "TOPRIGHT",
            button,
            "TOPRIGHT",
            -2,
            -2
        )

        icon:SetFrameStrata(
            "FULLSCREEN"
        )

        icon:SetFrameLevel(
            button:GetFrameLevel() + 500
        )

        icon:RegisterForClicks(
            "LeftButtonUp"
        )

        icon.texture =
            icon:CreateTexture(
                nil,
                "OVERLAY"
            )

        icon.texture:SetAllPoints()

        icon.texture:SetTexture(
            "Interface\\MoneyFrame\\UI-CopperIcon"
        )

        icon:SetScript(
            "OnClick",
            function(self)

                local button =
                    self.slotButton

                if not button then
                    return
                end

                local itemID =
                    GetButtonItemID(button)

                if not itemID then
                    return
                end

                local newState =
                    not IsItemMarked(itemID)

                SetMarked(
                    itemID,
                    newState
                )

                RecalculateMarkedValue()

                PlayToggleSound(
                    newState
                )

                ScanBagButtons()

                UpdateMerchantButton()

                if MerchantFrame
                and MerchantFrame:IsVisible() then

                    MerchantFrame_Update()

                end

            end
        )

        button.JMTrashIcon =
            icon

    end

    local icon =
        button.JMTrashIcon

    icon.slotButton =
        button

    icon:EnableMouse(true)

    if not itemID then

        icon:Hide()

        return

    end

    local vendorPrice =
        GetVendorPrice(
            itemID
        )

    if not vendorPrice
    or vendorPrice <= 0 then

        icon:Hide()

        return

    end

    if IsItemMarked(itemID) then

        icon:Show()

        icon.texture:SetAlpha(1)

        icon.texture:SetVertexColor(
            0.85,
            0.25,
            0.15
        )

    else

        icon.texture:SetAlpha(
            0.85
        )

        icon.texture:SetVertexColor(
            0.60,
            0.60,
            0.60
        )

        if button:IsMouseOver()
        or icon:IsMouseOver() then

            icon:Show()

        else

            icon:Hide()

        end

    end

end

--------------------------------------------------
-- Bag Hooks
--------------------------------------------------

local CachedButtons = {}
local ButtonsCached = false

local function CacheBagButtons()

    wipe(
        CachedButtons
    )

    for name, button in pairs(_G) do

        if type(name) == "string"
        and type(button) == "table"
        and button.GetObjectType then

            local ok, objectType =
                pcall(
                    button.GetObjectType,
                    button
                )

            if ok
            and objectType == "Button" then
                
                local info =
                    SafeGetButtonInfo(
                        button
                    )

                if info
                and (
                    info.itemID
                    or info.id
                ) then

                    table.insert(
                        CachedButtons,
                        button
                    )

                elseif name:find(
                    "^ContainerFrame%d+Item%d+$"
                ) then

                    table.insert(
                        CachedButtons,
                        button
                    )

                    if not button.JMHooked then

                        button.JMHooked = true

                        button:HookScript(
                            "OnEnter",
                            function(self)

                                UpdateSlotVisual(
                                    self
                                )

                            end
                        )

                        button:HookScript(
                            "OnLeave",
                            function(self)

                                UpdateSlotVisual(
                                    self
                                )

                            end
                        )

                    end

                end

            end

        end

    end

    ButtonsCached = true

end

ScanBagButtons = function()

    if not ButtonsCached then

        CacheBagButtons()

    end

    for _, button in ipairs(
        CachedButtons
    ) do

        if button then

            UpdateSlotVisual(
                button
            )

        end

    end

end

--------------------------------------------------
-- Merchant Helper
--------------------------------------------------

local function HasMarkedItems()

    for bag = 0, 4 do

        local numSlots =
            GetContainerNumSlots(bag)

        for slot = 1, numSlots do

            local link =
                GetContainerItemLink(
                    bag,
                    slot
                )

            local itemID =
                GetItemIDFromLink(link)

            if itemID
            and IsItemMarked(itemID) then

            local vendorPrice =
                GetVendorPrice(
                    itemID
                )

                if vendorPrice > 0 then

                    return true

                end

            end

        end

    end

    return false

end

UpdateMerchantButton = function()

    if not SellButton then
        return
    end

    if not MerchantFrame
    or not MerchantFrame:IsVisible() then
        return
    end

    if not SellButton:IsShown() then
        return
    end

    if HasMarkedItems() then

        SellButton:Enable()

        SellButton:SetAlpha(1.0)

        SellButton:SetNormalFontObject(
            "GameFontNormal"
        )

    else

        SellButton:Disable()

        SellButton:SetAlpha(0.4)

        SellButton:SetNormalFontObject(
            "GameFontDisable"
        )

    end

end

--------------------------------------------------
-- Merchant Sell Helper
--------------------------------------------------

local SellFrame =
    CreateFrame("Frame")

local SellTimer = 0
local TotalSoldValue = 0

local SoldItemIDs = {}

local function FindNextJunkItem()

    for bag = 0, 4 do

        local numSlots =
            GetContainerNumSlots(bag)

        for slot = 1, numSlots do

            local link =
                GetContainerItemLink(
                    bag,
                    slot
                )

            local itemID =
                GetItemIDFromLink(link)

            if itemID
            and IsItemMarked(itemID) then

                local vendorPrice =
                    GetVendorPrice(
                        itemID
                    )

                if vendorPrice > 0 then

                    return bag,
                           slot,
                           itemID

                end

            end

        end

    end

    return nil

end

--------------------------------------------------
-- Seller Processor
--------------------------------------------------

local function ProcessSelling(
    self,
    elapsed
)

    SellTimer =
        SellTimer + elapsed

    if SellTimer < 0.20 then
        return
    end

    SellTimer = 0

    local bag,
          slot,
          itemID =
        FindNextJunkItem()

    if not bag then

        SellFrame:SetScript(
            "OnUpdate",
            nil
        )

        for itemID in pairs(
            SoldItemIDs
        ) do

            SetMarked(
                itemID,
                false
            )

        end

        wipe(
            SoldItemIDs
        )

        if TotalSoldValue > 0 then

            Print(
                "Sold junk for " ..
                GetCoinTextureString(
                    TotalSoldValue
                )
            )

        else

            Print(
                "No marked junk items found."
            )

        end

        ScanBagButtons()

        UpdateMerchantButton()

        if MerchantFrame
        and MerchantFrame:IsVisible() then

            MerchantFrame_Update()

        end

        return

    end

    SoldItemIDs[itemID] = true

    UseContainerItem(
        bag,
        slot
    )

end

--------------------------------------------------
-- Merchant Sell
--------------------------------------------------

local function SellJunk()

    if SellFrame:GetScript(
        "OnUpdate"
    ) then
        return
    end

    wipe(
        SoldItemIDs
    )

    TotalSoldValue =
        GetMarkedItemValue()

    SellTimer = 0

    SellFrame:SetScript(
        "OnUpdate",
        ProcessSelling
    )

end

--------------------------------------------------
-- Buyback Tab Helper
--------------------------------------------------

local function ShowSellButton()

    if SellButton then

        SellButton:Show()

        UpdateMerchantButton()

    end

end

local function HideSellButton()

    if SellButton then

        SellButton:Hide()

    end

end

--------------------------------------------------
-- Merchant Button
--------------------------------------------------

IsBuybackTabSelected = function()

    if not MerchantFrameTab2 then
        return false
    end

    return
        MerchantFrameTab2:GetButtonState()
        == "PUSHED"

end

local TabsHooked = false

local function HookMerchantTabs()

    if TabsHooked then
        return
    end

    TabsHooked = true

    if MerchantFrameTab1 then

        MerchantFrameTab1:HookScript(
            "OnClick",
            ShowSellButton
        )

    end

    if MerchantFrameTab2 then

        MerchantFrameTab2:HookScript(
            "OnClick",
            HideSellButton
        )

    end

end

GetMarkedItemValue = function()

    return CurrentMarkedValue

end

local function CreateMerchantButton()

    if SellButton then
        return
    end

    SellButton =
        CreateFrame(
            "Button",
            "JunkMasterSellButton",
            MerchantFrame,
            "UIPanelButtonTemplate"
        )

    SellButton:SetWidth(75)
    SellButton:SetHeight(22)

    SellButton:SetText(
        "Sell Junk"
    )

    SellButton:SetScript(
        "OnClick",
        function()

            if PlaySound then

                PlaySound(1115) --BUTTON_CLICK_SOUND

            end

            SellJunk()

        end
    )

    SellButton:SetScript(
        "OnEnter",
        function(self)

            GameTooltip:SetOwner(
                self,
                "ANCHOR_TOP"
            )

            local value =
                GetMarkedItemValue()

            GameTooltip:AddLine(
                "JunkMaster",
                1,
                0.82,
                0
            )

            GameTooltip:AddDoubleLine(
                "Total Junk Value:",
                GetCoinTextureString(
                    value
                ),
                1, 1, 1,
                1, 1, 1
            )

            if value == 0 then

                GameTooltip:AddLine(
                    "No marked junk items found.",
                    0.7,
                    0.7,
                    0.7
                )

            end

            GameTooltip:Show()

        end
    )

    SellButton:SetScript(
        "OnLeave",
        function()

            GameTooltip:Hide()

        end
    )

end

local function PositionMerchantButton()

    CreateMerchantButton()

    SellButton:ClearAllPoints()

    SellButton:SetPoint(
        "BOTTOMLEFT",
        MerchantFrame,
        "BOTTOMLEFT",
        10,
        6
    )

    HookMerchantTabs()

    if IsBuybackTabSelected() then

        SellButton:Hide()

    else

        SellButton:Show()

        UpdateMerchantButton()

    end

end

--------------------------------------------------
-- Compatibility Helper
--------------------------------------------------

local function CleanupMissingMarkedItems()

    for itemID in pairs(
        JunkMasterDB.items
    ) do

        local found = false

        for bag = 0, 4 do

            local numSlots =
                GetContainerNumSlots(bag)

            for slot = 1, numSlots do

                local link =
                    GetContainerItemLink(
                        bag,
                        slot
                    )

                if GetItemIDFromLink(link)
                    == itemID then

                    found = true
                    break

                end

            end

            if found then
                break
            end

        end

        if not found then

            JunkMasterDB.items[itemID] = nil

        end

    end

end

--------------------------------------------------
-- Events
--------------------------------------------------

JM:RegisterEvent("PLAYER_LOGIN")
JM:RegisterEvent("BAG_UPDATE_DELAYED")
JM:RegisterEvent("MERCHANT_SHOW")
JM:RegisterEvent("MERCHANT_CLOSED")

local HoverElapsed = 0
local CacheRefreshTimer = 0

local function StartHoverUpdates()

    if not UsingBagnon then
        return
    end

    JM:SetScript(
        "OnUpdate",
        function(self, elapsed)

            HoverElapsed =
                HoverElapsed + elapsed

            CacheRefreshTimer =
                CacheRefreshTimer + elapsed

            if CacheRefreshTimer >= 1 then

                CacheRefreshTimer = 0

                ButtonsCached = false

            end

            if HoverElapsed >= 0.10 then

                HoverElapsed = 0

                ScanBagButtons()

            end

        end
    )

end

local function DelayedScan()

    local elapsedTotal = 0
    local passes = 0

    JM:SetScript(
        "OnUpdate",
        function(self, elapsed)

            elapsedTotal =
                elapsedTotal + elapsed

            if elapsedTotal >= 0.3 then

                elapsedTotal = 0

                passes =
                    passes + 1

                ScanBagButtons()

                if passes >= 5 then

                    if UsingBagnon then

                        StartHoverUpdates()

                    else

                        JM:SetScript(
                            "OnUpdate",
                            nil
                        )

                    end

                end

            end

        end
    )

end

JM:SetScript("OnEvent", function(self, event)

    if event == "PLAYER_LOGIN" then

        JunkMasterDB =
            JunkMasterDB or {}

        JunkMasterDB.items =
            JunkMasterDB.items or {}

        CacheBagButtons()

        RecalculateMarkedValue()

        DelayedScan()

    elseif event == "BAG_UPDATE_DELAYED" then

        CleanupMissingMarkedItems()

        RecalculateMarkedValue()

        ScanBagButtons()

        UpdateMerchantButton()

    elseif event == "MERCHANT_SHOW" then

        PositionMerchantButton()

        ShowSellButton()

        ScanBagButtons()

        UpdateMerchantButton()

    elseif event == "MERCHANT_CLOSED" then

        SellFrame:SetScript(
            "OnUpdate",
            nil
        )

        SellTimer = 0

        TotalSoldValue = 0

        wipe(
            SoldItemIDs
        )

    end

end)