local JM = CreateFrame("Frame")

--------------------------------------------------
-- Forward Declarations
--------------------------------------------------

local ScanBagButtons
local UpdateMerchantButton
local SellButton
local IsBuybackTabSelected
local GetMarkedItemValue
local IsItemMarked
local GetButtonItemID
local UpdateSlotVisual
local IsBagItemButton

local LastHoveredButton = nil

JunkMasterDB =
    JunkMasterDB or {}

JunkMasterDB.items =
    JunkMasterDB.items or {}

--------------------------------------------------
-- Utils
--------------------------------------------------

local function GetItemIDFromLink(link)

    if not link then
        return nil
    end

    return tonumber(
        string.match(
            link,
            "item:(%d+)"
        )
    )

end

local VendorPriceCache = {}

local CurrentMarkedValue = 0

local function GetVendorPrice(
    itemID
)

    if not itemID then
        return 0
    end

    local cached =
        VendorPriceCache[itemID]

    if cached ~= nil then

        return cached

    end

    local value =
        select(
            11,
            GetItemInfo(itemID)
        )

    if value == nil then

        return 0

    end

    VendorPriceCache[itemID] =
        value

    return value

end

local function RecalculateMarkedValue()

    CurrentMarkedValue = 0

    for bag = 0, 4 do

        local numSlots =
            GetContainerNumSlots(bag)

        for slot = 1, numSlots do

            local link =
                GetContainerItemLink(
                    bag,
                    slot
                )

            local itemID =
                GetItemIDFromLink(link)

            if itemID
            and IsItemMarked(itemID) then

                local texture,
                      itemCount =
                    GetContainerItemInfo(
                        bag,
                        slot
                    )

                CurrentMarkedValue =
                    CurrentMarkedValue +
                    (
                        GetVendorPrice(
                            itemID
                        )
                        *
                        (
                            itemCount
                            or 1
                        )
                    )

            end

        end

    end

end

IsItemMarked = function(itemID)

    return
        itemID
        and JunkMasterDB.items[itemID]

end

local function SetMarked(itemID, state)

    if not itemID then
        return
    end

    JunkMasterDB.items[itemID] =
        state or nil

end

local function Print(msg)

    DEFAULT_CHAT_FRAME:AddMessage(
        "|cffb87333JunkMaster:|r " ..
        tostring(msg)
    )

end

local function SafeGetButtonInfo(button)

    if not button then
        return nil
    end

    if button.GetInfo then

        local ok, info =
            pcall(
                button.GetInfo,
                button
            )

        if ok
        and type(info) == "table" then

            return info

        end

    end

    if type(button.info) == "table" then
        return button.info
    end

    return nil

end

--------------------------------------------------
-- Sounds
--------------------------------------------------

local function PlayToggleSound(enabled)

    if not PlaySound then
        return
    end

    if enabled then

        PlaySound(856)

    else

        PlaySound(857)

    end

end

--------------------------------------------------
-- Hover Helper
--------------------------------------------------

local function ShowHoverIcon(button)

    if not button then
        return
    end

    local name =
        button:GetName()

    if not name then
        return
    end

    if not (
        name:find("^ContainerFrame%d+Item%d+$")
        or
        name:find("^ContainerFrameItem%d+$")
    ) then

        return

    end

    local itemID =
        GetButtonItemID(button)

    if not itemID then
        return
    end

    if IsItemMarked(itemID) then
        return
    end

    if GetVendorPrice(itemID) <= 0 then
        return
    end

    LastHoveredButton =
    button

    UpdateSlotVisual(
        button
    )

end

local function HideHoverIcon(button)

    if not button then
        return
    end

    if button ==
        LastHoveredButton then

        LastHoveredButton =
            nil

    end

    UpdateSlotVisual(
        button
    )

end

--------------------------------------------------
-- Update Hovered Button
--------------------------------------------------

local function UpdateHoveredButton()

    local focus =
        GetMouseFocus()

    if not focus
    or not focus.GetName then

        return

    end

    if focus
    and focus.slotButton then

        focus =
            focus.slotButton

    end

    if not IsBagItemButton(
        focus
    ) then

        focus = nil

    end

    if focus ==
        LastHoveredButton then
        return
    end

    if LastHoveredButton then

        HideHoverIcon(
            LastHoveredButton
        )

    end

    LastHoveredButton =
        focus

    if focus then

        ShowHoverIcon(
            focus
        )

    end

end

--------------------------------------------------
-- Bag Item Helpers
--------------------------------------------------

GetButtonItemID = function(button)

    if not button then
        return nil
    end

    local info =
        SafeGetButtonInfo(
            button
        )

    if info then

        if info.itemID then

            return
                info.itemID

        end

        if info.link then

            return
                GetItemIDFromLink(
                    info.link
                )

        end

    end

    local name =
        button:GetName()

    if not name then
        return nil
    end

    if not (
        name:find(
            "^ContainerFrame%d+Item%d+$"
        )
        or
        name:find(
            "^ContainerFrameItem%d+$"
        )
    ) then

        return nil

    end

    local parent =
        button:GetParent()

    if not parent then
        return nil
    end

    local bag =
        parent:GetID()

    local slot =
        button:GetID()

    if bag == nil
    or not slot then

        return nil

    end

    local link =
        GetContainerItemLink(
            bag,
            slot
        )

    return
        GetItemIDFromLink(
            link
        )

end

--------------------------------------------------
-- Inventory Check
--------------------------------------------------

IsBagItemButton = function(button)

    if not button then
        return false
    end

    local name =
        button:GetName()

    if not name then
        return false
    end

    return
        name:find(
            "^ContainerFrame%d+Item%d+$"
        )
        ~= nil

end

--------------------------------------------------
-- Overlay Update
--------------------------------------------------

UpdateSlotVisual = function(button)

    if not button then
        return
    end

    local itemID =
        GetButtonItemID(
            button
        )

    if not itemID then

        if button.JMTrashIcon then

            button.JMTrashIcon:Hide()

            button.JMTrashIcon:EnableMouse(
                false
            )

        end

        return

    end

    local vendorPrice =
        GetVendorPrice(
            itemID
        )

    if vendorPrice <= 0 then

        if button.JMTrashIcon then

            button.JMTrashIcon:Hide()

            button.JMTrashIcon:EnableMouse(
                false
            )

        end

        return

    end

    if not button.JMTrashIcon then

        local icon =
            CreateFrame(
                "Button",
                nil,
                button
            )

        icon:SetWidth(14)
        icon:SetHeight(14)

        icon:SetPoint(
            "TOPRIGHT",
            button,
            "TOPRIGHT",
            -2,
            -2
        )

        icon:SetFrameStrata(
            "TOOLTIP"
        )

        icon:SetFrameLevel(
            button:GetFrameLevel()
            + 100
        )

        icon:RegisterForClicks(
            "LeftButtonUp"
        )

        icon.texture =
            icon:CreateTexture(
                nil,
                "OVERLAY"
            )

        icon.texture:SetAllPoints()

        icon.texture:SetTexture(
            "Interface\\MoneyFrame\\UI-CopperIcon"
        )

        icon:SetScript(
            "OnClick",
            function(self)

                local slotButton =
                    self.slotButton

                if not slotButton then
                    return
                end

                local itemID =
                    GetButtonItemID(
                        slotButton
                    )

                if not itemID then
                    return
                end

                local newState =
                    not IsItemMarked(
                        itemID
                    )

                SetMarked(
                    itemID,
                    newState
                )

                RecalculateMarkedValue()

                PlayToggleSound(
                    newState
                )

                ScanBagButtons()

                UpdateMerchantButton()

                if MerchantFrame
                and MerchantFrame:IsVisible() then

                    MerchantFrame_Update()

                end

            end
        )

        icon:Hide()

        button.JMTrashIcon =
            icon

    end

    local icon =
        button.JMTrashIcon

    icon.slotButton =
        button

    local hovered =
        (
            button ==
            LastHoveredButton
        )

    if IsItemMarked(
        itemID
    ) then

        icon:Show()

        icon:EnableMouse(
            true
        )

        icon.texture:SetAlpha(
            1
        )

        icon.texture:SetVertexColor(
            0.85,
            0.25,
            0.15
        )

    elseif hovered then

        icon:Show()

        icon:EnableMouse(
            true
        )

        icon.texture:SetAlpha(
            0.85
        )

        icon.texture:SetVertexColor(
            0.60,
            0.60,
            0.60
        )

    else

        icon:Hide()

        icon:EnableMouse(
            false
        )

    end

end

--------------------------------------------------
-- Bag Hooks
--------------------------------------------------

local CachedButtons = {}
local ButtonsCached = false

local function CacheBagButtons()

    wipe(
        CachedButtons
    )

    for name, button in pairs(_G) do

        if type(name) == "string"
        and type(button) == "table"
        and button.GetObjectType then

            local ok,
                  objectType =
                pcall(
                    button.GetObjectType,
                    button
                )

            if ok
            and objectType == "Button" then

                local itemID =
                    GetButtonItemID(
                        button
                    )

                if itemID then

                    table.insert(
                        CachedButtons,
                        button
                    )

                elseif name:find(
                    "^ContainerFrame%d+Item%d+$"
                ) then

                    table.insert(
                        CachedButtons,
                        button
                    )

                end

            end

        end

    end

    ButtonsCached = true

end

ScanBagButtons = function()

    if not ButtonsCached then

        CacheBagButtons()

    end

    for _, button in ipairs(
        CachedButtons
    ) do

        if button then

            UpdateSlotVisual(
                button
            )

        end

    end

end

--------------------------------------------------
-- Merchant Helper
--------------------------------------------------

local function HasMarkedItems()

    for bag = 0, 4 do

        local numSlots =
            GetContainerNumSlots(bag)

        for slot = 1, numSlots do

            local link =
                GetContainerItemLink(
                    bag,
                    slot
                )

            local itemID =
                GetItemIDFromLink(link)

            if itemID
            and IsItemMarked(itemID) then

            local vendorPrice =
                GetVendorPrice(
                    itemID
                )

                if vendorPrice > 0 then

                    return true

                end

            end

        end

    end

    return false

end

UpdateMerchantButton = function()

    if not SellButton then
        return
    end

    if not MerchantFrame
    or not MerchantFrame:IsVisible() then
        return
    end

    if not SellButton:IsShown() then
        return
    end

    if HasMarkedItems() then

        SellButton:Enable()

        SellButton:SetAlpha(1.0)

        SellButton:SetNormalFontObject(
            "GameFontNormal"
        )

    else

        SellButton:Disable()

        SellButton:SetAlpha(0.4)

        SellButton:SetNormalFontObject(
            "GameFontDisable"
        )

    end

end

--------------------------------------------------
-- Merchant Sell Helper
--------------------------------------------------

local SellFrame =
    CreateFrame("Frame")

local SellTimer = 0
local ActualSoldValue = 0

local SoldItemIDs = {}

local function FindNextJunkItem()

    for bag = 0, 4 do

        local numSlots =
            GetContainerNumSlots(bag)

        for slot = 1, numSlots do

            local link =
                GetContainerItemLink(
                    bag,
                    slot
                )

            local itemID =
                GetItemIDFromLink(link)

            if itemID
            and IsItemMarked(itemID) then

                local vendorPrice =
                    GetVendorPrice(
                        itemID
                    )

                if vendorPrice > 0 then

                    return bag,
                           slot,
                           itemID

                end

            end

        end

    end

    return nil

end

--------------------------------------------------
-- Seller Processor
--------------------------------------------------

local function ProcessSelling(
    self,
    elapsed
)

    SellTimer =
        SellTimer + elapsed

    if SellTimer < 0.5 then
        return
    end

    SellTimer = 0

    local bag,
          slot,
          itemID =
        FindNextJunkItem()

    if not bag then

        SellFrame:SetScript(
            "OnUpdate",
            nil
        )

        for itemID in pairs(
            SoldItemIDs
        ) do

            SetMarked(
                itemID,
                false
            )

        end

        wipe(
            SoldItemIDs
        )

        if ActualSoldValue > 0 then

            Print(
                "Sold junk for " ..
                GetCoinTextureString(
                    ActualSoldValue
                )
            )  

        else

            Print(
                "No marked junk items found."
            )

        end

        ActualSoldValue = 0

        LastHoveredButton = nil

        ScanBagButtons()

        UpdateMerchantButton()

        if MerchantFrame
        and MerchantFrame:IsVisible() then

            MerchantFrame_Update()

        end

        return

    end

    SoldItemIDs[itemID] = true

    local texture,
        itemCount =
        GetContainerItemInfo(
            bag,
            slot
        )

    ActualSoldValue =
        ActualSoldValue +
        (
            GetVendorPrice(
                itemID
            )
            *
            (
                itemCount
                or 1
            )
        )

    UseContainerItem(
        bag,
        slot
    )

end

--------------------------------------------------
-- Merchant Sell
--------------------------------------------------

local function SellJunk()

    if SellFrame:GetScript(
        "OnUpdate"
    ) then
        return
    end

    wipe(
        SoldItemIDs
    )

    ActualSoldValue = 0

    SellTimer = 0

    SellFrame:SetScript(
        "OnUpdate",
        ProcessSelling
    )

end

--------------------------------------------------
-- Buyback Tab Helper
--------------------------------------------------

local function ShowSellButton()

    if SellButton then

        SellButton:Show()

        UpdateMerchantButton()

    end

end

local function HideSellButton()

    if SellButton then

        SellButton:Hide()

    end

end

--------------------------------------------------
-- Merchant Button
--------------------------------------------------

IsBuybackTabSelected = function()

    if not MerchantFrameTab2 then
        return false
    end

    return
        MerchantFrameTab2:GetButtonState()
        == "PUSHED"

end

local TabsHooked = false

local function HookMerchantTabs()

    if TabsHooked then
        return
    end

    TabsHooked = true

    if MerchantFrameTab1 then

        MerchantFrameTab1:HookScript(
            "OnClick",
            ShowSellButton
        )

    end

    if MerchantFrameTab2 then

        MerchantFrameTab2:HookScript(
            "OnClick",
            HideSellButton
        )

    end

end

GetMarkedItemValue = function()

    return CurrentMarkedValue

end

local function CreateMerchantButton()

    if SellButton then
        return
    end

    SellButton =
        CreateFrame(
            "Button",
            "JunkMasterSellButton",
            MerchantFrame,
            "UIPanelButtonTemplate"
        )

    SellButton:SetWidth(75)
    SellButton:SetHeight(22)

    SellButton:SetText(
        "Sell Junk"
    )

    SellButton:SetScript(
        "OnClick",
        function()

            if PlaySound then

                PlaySound(1115) --BUTTON_CLICK_SOUND

            end

            SellJunk()

        end
    )

    SellButton:SetScript(
        "OnEnter",
        function(self)

            GameTooltip:SetOwner(
                self,
                "ANCHOR_TOP"
            )

            local value =
                GetMarkedItemValue()

            GameTooltip:AddLine(
                "JunkMaster",
                1,
                0.82,
                0
            )

            GameTooltip:AddDoubleLine(
                "Total Junk Value:",
                GetCoinTextureString(
                    value
                ),
                1, 1, 1,
                1, 1, 1
            )

            if value == 0 then

                GameTooltip:AddLine(
                    "No marked junk items found.",
                    0.7,
                    0.7,
                    0.7
                )

            end

            GameTooltip:Show()

        end
    )

    SellButton:SetScript(
        "OnLeave",
        function()

            GameTooltip:Hide()

        end
    )

end

local function PositionMerchantButton()

    CreateMerchantButton()

    SellButton:ClearAllPoints()

    SellButton:SetPoint(
        "BOTTOMLEFT",
        MerchantFrame,
        "BOTTOMLEFT",
        10,
        6
    )

    HookMerchantTabs()

    if IsBuybackTabSelected() then

        SellButton:Hide()

    else

        SellButton:Show()

        UpdateMerchantButton()

    end

end

--------------------------------------------------
-- Compatibility Helper
--------------------------------------------------

local function CleanupMissingMarkedItems()

    for itemID in pairs(
        JunkMasterDB.items
    ) do

        local found = false

        for bag = 0, 4 do

            local numSlots =
                GetContainerNumSlots(bag)

            for slot = 1, numSlots do

                local link =
                    GetContainerItemLink(
                        bag,
                        slot
                    )

                if GetItemIDFromLink(link)
                    == itemID then

                    found = true
                    break

                end

            end

            if found then
                break
            end

        end

        if not found then

            JunkMasterDB.items[itemID] = nil

        end

    end

end

--------------------------------------------------
-- Events
--------------------------------------------------

JM:RegisterEvent(
    "PLAYER_LOGIN"
)

JM:RegisterEvent(
    "BAG_UPDATE_DELAYED"
)

JM:RegisterEvent(
    "MERCHANT_SHOW"
)

JM:RegisterEvent(
    "MERCHANT_CLOSED"
)

local HoverElapsed = 0

local function StartHoverUpdates()

    JM:SetScript(
        "OnUpdate",
        function(self, elapsed)

            HoverElapsed =
                HoverElapsed + elapsed

            if HoverElapsed < 0.10 then
                return
            end

            HoverElapsed = 0

            UpdateHoveredButton()

        end
    )

end

local function DelayedScan()

    local elapsedTotal = 0
    local passes = 0

    JM:SetScript(
        "OnUpdate",
        function(self, elapsed)

            elapsedTotal =
                elapsedTotal + elapsed

            if elapsedTotal < 0.30 then
                return
            end

            elapsedTotal = 0

            passes =
                passes + 1

            ButtonsCached =
                false

            ScanBagButtons()

            local STARTUP_SCAN_PASSES = 10

            if passes < STARTUP_SCAN_PASSES then
                return
            end

            StartHoverUpdates()

        end
    )

end

JM:SetScript(
    "OnEvent",
    function(self, event)

        if event == "PLAYER_LOGIN" then

            JunkMasterDB =
                JunkMasterDB or {}

            JunkMasterDB.items =
                JunkMasterDB.items or {}

            CacheBagButtons()

            CleanupMissingMarkedItems()

            RecalculateMarkedValue()

            DelayedScan()

        elseif event ==
            "BAG_UPDATE_DELAYED" then

            ButtonsCached =
                false

            CleanupMissingMarkedItems()

            RecalculateMarkedValue()

            ScanBagButtons()

            UpdateMerchantButton()

        elseif event ==
            "MERCHANT_SHOW" then

            PositionMerchantButton()

            ScanBagButtons()

            UpdateMerchantButton()

        elseif event ==
            "MERCHANT_CLOSED" then

            if SellFrame:GetScript(
                "OnUpdate"
            )
            and ActualSoldValue > 0 then

                Print(
                    "Sold junk for " ..
                    GetCoinTextureString(
                        ActualSoldValue
                    )
                )

            end

            SellFrame:SetScript(
                "OnUpdate",
                nil
            )

            SellTimer = 0

            ActualSoldValue = 0

            for itemID in pairs(
                SoldItemIDs
            ) do

                SetMarked(
                    itemID,
                    false
                )

            end            

            wipe(
                SoldItemIDs
            )

        end

    end
)