local BAD_TEXT =
"All the fisherman have moved to Darnassus with the recent attacks around Lake Al'Ameth.  You should try looking for someone to train you there."

local function RandomFrom(tbl)

    if not tbl or #tbl == 0 then
        return nil
    end

    return tbl[math.random(#tbl)]
end

--------------------------------------------------
-- Gossip Helper
--------------------------------------------------

local CachedGossipText

local function BuildGossipCache()

    CachedGossipText = ""

    for i = 1, 32 do

        local button = _G["GossipTitleButton" .. i]

        if button and button:IsShown() then

            local text = button:GetText()

            if text then
                CachedGossipText =
                    CachedGossipText .. " " .. string.lower(text)
            end

        end

    end

end

--------------------------------------------------
-- Gossip Options
--------------------------------------------------

local function HasGossipOption(search)

    if not CachedGossipText then
        return false
    end

    return CachedGossipText:find(
        string.lower(search),
        1,
        true
    ) ~= nil
end

--------------------------------------------------
-- NPC Title Cache
--------------------------------------------------

local CachedTitle
local CachedName

local function ClearNPCTitleCache()

    CachedTitle = nil
    CachedName = nil
    CachedGossipText = nil

end

--------------------------------------------------
-- NPC Title Detection
--------------------------------------------------

local function GetNPCTitle()

    if not UnitExists("npc") then
        ClearNPCTitleCache()
        return nil
    end

    local npcName = UnitName("npc")

    if CachedName == npcName then
        return CachedTitle
    end

    CachedName = npcName
    CachedTitle = nil

    GameTooltip:SetOwner(UIParent, "ANCHOR_NONE")
    GameTooltip:SetUnit("npc")

    local lines = GameTooltip:NumLines() or 0

    for i = 2, lines do

        local line = _G["GameTooltipTextLeft" .. i]

        if line then

            local text = line:GetText()

            if text and text ~= "" then

                CachedTitle = text
                break

            end

        end

    end

    GameTooltip:Hide()

    return CachedTitle
end

--------------------------------------------------
-- Cache Reset Events
--------------------------------------------------

local CacheFrame = CreateFrame("Frame")

CacheFrame:RegisterEvent("GOSSIP_CLOSED")

CacheFrame:SetScript("OnEvent", function()
    ClearNPCTitleCache()
end)

--------------------------------------------------
-- Detect NPC Type
--------------------------------------------------

local function DetectTrainerType()

    local numServices = GetNumTrainerServices and GetNumTrainerServices() or 0

    for i = 1, numServices do

        local name = GetTrainerServiceInfo(i)

        if name then

            local lower = string.lower(name)

            -- Enchanting
            if lower:find("enchant")
            or lower:find("runed copper rod")
            or lower:find("runed silver rod")
            or lower:find("runed golden rod")
            or lower:find("runed truesilver rod")
            or lower:find("runed arcanite rod")
            then
                return "Enchanting"
            end

            -- Alchemy
            if lower:find("potion")
            or lower:find("elixir")
            or lower:find("transmute")
            or lower:find("alchemy")
            then
                return "Alchemy"
            end

            -- Engineering
            if lower:find("copper tube")
            or lower:find("blasting powder")
            or lower:find("dynamite")
            or lower:find("target dummy")
            or lower:find("engineering")
            then
                return "Engineering"
            end

            -- Blacksmithing
            if lower:find("rough whetstone")
            or lower:find("sharpening stone")
            or lower:find("copper chain")
            or lower:find("rough copper")
            or lower:find("blacksmith")
            then
                return "Blacksmithing"
            end

            -- Tailoring
            if lower:find("bolt of linen")
            or lower:find("brown linen")
            or lower:find("linen cloak")
            or lower:find("tailoring")
            then
                return "Tailoring"
            end

            -- Leatherworking
            if lower:find("light armor kit")
            or lower:find("handstitched")
            or lower:find("leatherworking")
            or lower:find("leatherworker")
            then
                return "Leatherworking"
            end

            -- First Aid
            if lower:find("linen bandage")
            or lower:find("heavy linen bandage")
            or lower:find("first aid")
            then
                return "First Aid"
            end

            -- Cooking
            if lower:find("cook")
            or lower:find("cooking trainer")
            or lower:find("master cook")
            or lower:find("chef")
            then
                return "Cooking"
            end

            -- Fishing
            if lower:find("fishing") then
                return "Fishing"
            end

            -- Herbalism
            if lower:find("find herbs")
            or lower:find("herbalism")
            then
                return "Herbalism"
            end

            -- Mining
            if lower:find("find minerals")
            or lower:find("mining")
            then
                return "Mining"
            end

            -- Skinning
            if lower:find("skinning") then
                return "Skinning"
            end

            -- Lockpicking
            if lower:find("lockpicking") then
                return "Lockpicking"
            end

        end

    end

    local title = GetNPCTitle()

    if not title then
        return nil
    end

    local lower = string.lower(title)

    -- Profession Trainers

    if lower:find("enchanter", 1, true)
    or lower:find("enchanting trainer", 1, true)
    then
        return "Enchanting"
    end

    if lower:find("alchemist", 1, true)
    or lower:find("alchemy trainer", 1, true)
    then
        return "Alchemy"
    end

    if lower:find("engineer", 1, true)
    or lower:find("engineering trainer", 1, true)
    then
        return "Engineering"
    end

    if lower:find("blacksmith", 1, true)
    or lower:find("blacksmith trainer", 1, true)
    or lower:find("armorsmith", 1, true)
    or lower:find("weaponsmith", 1, true)
    then
        return "Blacksmithing"
    end

    if lower:find("tailor", 1, true)
    or lower:find("tailoring trainer", 1, true)
    then
        return "Tailoring"
    end

    if lower:find("leatherworker", 1, true)
    or lower:find("leatherworking trainer", 1, true)
    or lower:find("dragonscale leatherworker", 1, true)
    or lower:find("tribal leatherworker", 1, true)
    or lower:find("elemental leatherworker", 1, true)
    then
        return "Leatherworking"
    end

    if lower:find("fisherman", 1, true)
    or lower:find("fishing trainer", 1, true)
    then
        return "Fishing"
    end

    if lower:find("cook", 1, true)
    or lower:find("cooking trainer", 1, true)
    or lower:find("chef", 1, true)
    then
        return "Cooking"
    end

    if lower:find("first aid trainer", 1, true)
    or lower:find("physician", 1, true)
    or lower:find("medic", 1, true)
    or lower:find("surgeon", 1, true)
    then
        return "First Aid"
    end

    if lower:find("herbalist", 1, true)
    or lower:find("herbalism trainer", 1, true)
    then
        return "Herbalism"
    end

    if lower:find("miner", 1, true)
    or lower:find("mining trainer", 1, true)
    then
        return "Mining"
    end

    if lower:find("skinner", 1, true)
    or lower:find("skinning trainer", 1, true)
    then
        return "Skinning"
    end

    if lower:find("lockpicking trainer", 1, true) then
        return "Lockpicking"
    end

    -- Class Trainers

    if lower:find("druid trainer", 1, true)
    or lower:find("archdruid", 1, true)
    or lower:find("keeper of the grove", 1, true)
    then
        return "Druid"
    end

    if lower:find("hunter trainer", 1, true) then
        return "Hunter"
    end

    if lower:find("mage trainer", 1, true)
    or lower:find("wizard", 1, true)
    or lower:find("sorcerer", 1, true)
    then
        return "Mage"
    end

    if lower:find("paladin trainer", 1, true) then
        return "Paladin"
    end

    if lower:find("priest trainer", 1, true)
    or lower:find("priestess", 1, true)
    or lower:find("high priest", 1, true)
    then
        return "Priest"
    end

    if lower:find("rogue trainer", 1, true) then
        return "Rogue"
    end

    if lower:find("shaman trainer", 1, true)
    or lower:find("far seer", 1, true)
    then
        return "Shaman"
    end

    if lower:find("warlock trainer", 1, true) then
        return "Warlock"
    end

    if lower:find("warrior trainer", 1, true) then
        return "Warrior"
    end

    return nil
end

--------------------------------------------------
-- Text Blocks
--------------------------------------------------

local TrainerText = {

    Enchanting = {
        "Arcane energies leave their mark on all things.",
        "The finest enchantments begin with patience and knowledge.",
        "Few truly understand the complexities of enchanting.",
        "Magic surrounds us constantly. Learning to direct it is the difficult part.",
        "A well-crafted enchantment can transform even ordinary equipment.",
        "The art of enchanting rewards dedicated students.",
        "Even the simplest enchantment contains hidden principles.",
        "Understanding magic is often more important than wielding it.",
    },

    Alchemy = {
        "Many discoveries begin with a single herb and a curious mind.",
        "Alchemy rewards observation as much as experimentation.",
        "Reagents often possess properties that are not immediately obvious.",
        "There are many secrets hidden within herbs and elixirs.",
        "A skilled alchemist sees possibilities others overlook.",
        "Knowledge of ingredients is just as important as knowledge of results.",
        "Every mixture has something to teach.",
        "The difference between success and failure is often measured in drops.",
    },

    Engineering = {
        "Innovation begins with curiosity.",
        "A good engineer is never afraid of a little trial and error.",
        "Every device teaches a lesson, even when it explodes.",
        "Ingenuity often solves problems brute force cannot.",
        "The best inventions begin as simple ideas.",
        "Few fields reward creativity quite like engineering.",
        "Understanding why something failed is often the first step toward success.",
        "There is always a better design waiting to be discovered.",
    },

    Blacksmithing = {
        "Steel is shaped by patience, fire, and determination.",
        "The forge teaches discipline to all who work beside it.",
        "A masterwork begins with proper fundamentals.",
        "Strength alone does not make a skilled smith.",
        "A blade is only as good as the craftsmanship behind it.",
        "Good steel earns respect long before it sees battle.",
        "Every strike of the hammer has purpose.",
        "Quality takes time to create.",
    },

    Tailoring = {
        "Precision and patience are the foundation of fine tailoring.",
        "Skilled hands can create remarkable things from simple cloth.",
        "Every tailor begins with thread and determination.",
        "The smallest details often matter most.",
        "Fine craftsmanship never goes out of style.",
        "Careful work leaves a lasting impression.",
        "A practiced tailor sees possibilities in every bolt of cloth.",
    },

    Leatherworking = {
        "Nature provides many useful materials to those who understand them.",
        "A skilled leatherworker wastes nothing of value.",
        "Every hide presents an opportunity to improve your craft.",
        "Leatherworking combines utility with artistry.",
        "Good workmanship always reveals itself over time.",
        "Experience teaches which materials deserve special attention.",
        "The wilderness is a generous teacher.",
    },

    Cooking = {
        "A hearty meal strengthens both body and spirit.",
        "Even adventurers remember a good meal.",
        "Every cook begins with simple recipes.",
        "Good food can make any journey easier.",
        "The kitchen rewards patience as much as talent.",
        "Simple ingredients often produce the best meals.",
        "A good meal brings people together.",
    },

    ["First Aid"] = {
        "Knowing how to treat wounds is a valuable skill.",
        "Preparation often means the difference between success and failure.",
        "Every adventurer benefits from learning basic medical care.",
        "A steady hand can save a life.",
        "Experience teaches many lessons. First aid helps you survive them.",
        "The best treatment is often applied before trouble grows worse.",
        "Self-reliance is a valuable trait in dangerous times.",
    },

    Default = {
        "If you seek knowledge, I will gladly share what I have learned.",
        "There is always room to improve one's skills.",
        "A willing student can learn much.",
        "Experience is best passed from teacher to student.",
        "I can help you continue your training.",
        "Knowledge should not be wasted.",
    }
}

local GenericNPCText = {
    "Greetings. How may I assist you?",
    "Welcome. What brings you here today?",
    "Good day to you.",
    "It is always nice to see a friendly face.",
    "Can I help you with something?",
    "What can I do for you?",
    "The world is full of opportunity for those willing to seek it.",
    "Another traveler. Interesting.",
    "These are uncertain times, but life goes on.",
    "Every day seems to bring new stories.",
    "The roads are never short of surprises.",
    "Life has a way of keeping things interesting.",
}

local Flavor = {
    "Experience remains the finest teacher.",
    "There is always more to learn.",
    "Patience often rewards the diligent.",
    "The world changes, but wisdom endures.",
    "A careful mind rarely goes astray.",
    "Preparation is rarely wasted effort.",
}

local QuestNPCText = {
    "You seem capable. There may be a matter requiring attention.",
    "I have something that may interest an adventurer such as yourself.",
    "There is always work to be done around here.",
    "Perhaps you can lend a hand.",
    "I may have use for someone with your talents.",
    "A reliable traveler is difficult to find these days.",
    "I've been hoping someone would come along.",
    "There are problems that still need solving.",
    "You appear more capable than most who pass through here.",
    "Perhaps fortune brought you here for a reason.",
}

local VendorText = {
    "Take a look at my wares. You may find something useful.",
    "Quality goods for those who appreciate them.",
    "A prepared traveler is usually a successful traveler.",
    "I carry supplies for all manner of journeys.",
    "Perhaps there is something here that catches your eye.",
    "Good merchandise speaks for itself.",
    "One never knows what might prove useful out in the wilds.",
    "Trade keeps the world moving.",
    "I've done business with all sorts over the years.",
    "The right purchase today may save trouble tomorrow.",
}

local InnkeeperText = {
    "Welcome, traveler. Rest and make yourself at home.",
    "A warm meal and a soft bed await.",
    "Everyone needs a place to rest after a long road.",
    "Stay awhile and recover your strength.",
    "You've traveled far. Take a moment to rest.",
    "Roads are easier to face after a good night's sleep.",
    "The hearth is always warm for respectful guests.",
    "Many stories begin over a meal and a drink.",
}

local FlightMasterText = {
    "Need a ride? We can get you where you're going.",
    "The skies connect places roads never could.",
    "Looking to travel? You've come to the right place.",
    "Our routes are swift and reliable.",
    "Aerial travel saves many days on the road.",
    "The view is worth the trip alone.",
    "Few journeys are quicker than those made through the skies.",
    "My mounts know these routes by heart.",
}

local StableMasterText = {
    "Your companions will be well cared for here.",
    "Every beast deserves proper care and attention.",
    "I can look after your animals while you're away.",
    "A loyal companion deserves proper treatment.",
    "Trust between rider and beast is not easily earned.",
    "Even the strongest beasts benefit from rest.",
}

local BankerText = {
    "Your belongings will remain secure with us.",
    "Safe storage is a wise investment.",
    "We pride ourselves on reliable service.",
    "Many travelers sleep better knowing their valuables are secure.",
    "Careful planning begins with careful management.",
    "Security and discretion are our specialties.",
}

local TitleSpecificText = {

    ["weapon merchant"] = {
        "A reliable weapon is often the difference between victory and defeat.",
        "Choose your weapon carefully. One day, your life may depend on it.",
        "Good steel earns respect long before it sees battle.",
        "Every weapon has a purpose. Finding the right one is the important part.",
        "The finest blade in the world is worthless in untrained hands.",
    },

    ["armorer"] = {
        "Armor may not win every battle, but it can help you survive one.",
        "A wise adventurer values protection as much as offense.",
        "Good armor tends to outlast reckless decisions.",
        "Many heroes owe their lives to a sturdy breastplate.",
        "Steel and craftsmanship make a dependable combination.",
    },

    ["gunsmith"] = {
        "A well-crafted firearm rewards patience and precision.",
        "Quality engineering makes all the difference.",
        "The best marksmen trust their equipment as much as their skill.",
        "A firearm is only as reliable as the hands that crafted it.",
    },

    ["bowyer"] = {
        "A skilled archer understands the value of a well-made bow.",
        "Good wood and careful craftsmanship go hand in hand.",
        "Precision begins with proper equipment.",
        "The finest bows are built with patience, not haste.",
    },

    ["general goods"] = {
        "One never knows what might prove useful on the road.",
        "Prepared travelers tend to fare better than unprepared ones.",
        "You can find a little bit of everything here.",
        "A wise adventurer plans ahead whenever possible.",
    },

    ["trade supplies"] = {
        "Craftsmen from every corner of Azeroth rely on dependable supplies.",
        "Every finished masterpiece begins with basic materials.",
        "Tools and materials are the foundation of every trade.",
        "A good craftsman never neglects preparation.",
    },

    ["supplies"] = {
        "Preparation is rarely wasted effort.",
        "Even the most experienced adventurers require supplies from time to time.",
        "The right supplies can make difficult tasks considerably easier.",
        "A well-stocked pack is always a welcome sight.",
    },

    ["reagents"] = {
        "Arcane pursuits require proper materials.",
        "You'll find components for nearly any magical endeavor.",
        "A wise spellcaster rarely runs short on reagents.",
        "The most impressive spells often begin with humble ingredients.",
    },

    ["food & drink"] = {
        "A hot meal can do wonders for weary travelers.",
        "No adventurer performs well on an empty stomach.",
        "Good food strengthens both body and spirit.",
        "Every long journey is easier with a proper meal.",
    },

    ["provisioner"] = {
        "Every expedition begins with proper provisions.",
        "Supplies have a habit of becoming important when least expected.",
        "The road is much easier with a well-stocked pack.",
        "Preparation often determines success.",
    },

    ["herbalism supplies"] = {
        "A trained eye can find value in even the simplest plant.",
        "Nature provides many useful resources.",
        "Knowledge and patience are an herbalist's greatest tools.",
        "The wilderness holds countless secrets waiting to be discovered.",
    },

    ["alchemy supplies"] = {
        "Many remarkable discoveries begin with a single ingredient.",
        "Alchemy rewards curiosity and careful observation.",
        "Quality reagents are worth acquiring when available.",
        "Every potion begins with proper preparation.",
    },

    ["fishing supplies"] = {
        "Patience is the first lesson every angler learns.",
        "The waters of Azeroth offer opportunity to those willing to wait.",
        "A good fisher understands that persistence often pays off.",
        "Every successful catch begins with proper equipment.",
    },

    ["mining supplies"] = {
        "The earth hides countless riches beneath its surface.",
        "A sturdy pick and determination take a miner far.",
        "Many fortunes have begun with a single promising vein.",
        "The best miners learn where to look.",
    },

    ["gryphon master"] = {
        "The skies offer the fastest route to many destinations.",
        "Few sights compare to Azeroth viewed from above.",
        "My gryphons know these routes well.",
        "Travel is simpler when you leave the roads behind.",
    },

    ["wind rider master"] = {
        "The open skies connect the Horde's lands.",
        "A skilled wind rider can reach places roads never could.",
        "The winds favor those willing to take advantage of them.",
        "Travel swiftly and safely.",
    },

    ["flight master"] = {
        "The skies connect places roads never could.",
        "Aerial travel saves many days on the road.",
        "Our routes are swift and reliable.",
        "The view alone is often worth the journey.",
    },

    ["stable master"] = {
        "Your companions will be cared for as if they were my own.",
        "Every beast deserves proper care and attention.",
        "Even the fiercest companion benefits from rest.",
        "Trust is important when caring for animals.",
    },

    ["innkeeper"] = {
        "Welcome, traveler. Rest and make yourself comfortable.",
        "There is always room beside a warm hearth.",
        "Road-weary adventurers are common guests here.",
        "A good night's rest can work wonders.",
    },

    ["banker"] = {
        "Your valuables are safer here than in most packs.",
        "A secure vault provides peace of mind.",
        "Many travelers entrust us with their belongings.",
        "Careful planning often begins with careful storage.",
    },

    ["master enchanter"] = {
        "Mastery of enchanting requires far more than simple talent.",
        "The deepest mysteries of enchanting reveal themselves only through dedication.",
        "Even experienced enchanters continue learning throughout their lives.",
        "Power alone is never enough. Understanding matters more.",
    },

    ["expert enchanter"] = {
        "Many begin the study of enchanting. Few remain committed long enough to excel.",
        "The fundamentals of enchanting reward patience and discipline.",
        "A solid foundation is worth more than many shortcuts.",
        "Understanding the principles behind an enchantment is every bit as important as casting it.",
    },

    ["master blacksmith"] = {
        "Years at the forge teach lessons no apprentice can learn from books.",
        "A master smith understands both steel and patience.",
        "Great craftsmanship is earned one strike at a time.",
        "The forge rewards dedication above all else.",
    },

    ["expert blacksmith"] = {
        "The basics are important, but experience refines true skill.",
        "Steel teaches something new every day.",
        "Many can shape iron. Far fewer can master it.",
        "The forge rewards those willing to learn.",
    },

    ["master alchemist"] = {
        "The greatest discoveries often come after years of study.",
        "Mastery comes from understanding why an experiment succeeds.",
        "There is always another mystery waiting to be unraveled.",
        "A true alchemist never stops learning.",
    },

    ["expert alchemist"] = {
        "Practical experience teaches lessons that theory alone cannot.",
        "Skill grows through careful experimentation.",
        "Observation is often as valuable as knowledge.",
        "A wise alchemist learns something from every mixture.",
    },

    ["sentinel"] = {
        "The forests of Kalimdor have been watched over for generations.",
        "Vigilance is a duty that never truly ends.",
        "Many dangers reveal themselves only to those paying attention.",
        "Patience and discipline are valuable virtues.",
    },

    ["guard"] = {
        "Keeping the peace is often less glamorous than adventurers imagine.",
        "Every settlement relies on those willing to stand watch.",
        "Most days are quiet. We prefer it that way.",
        "Order requires constant attention.",
    },
}

--------------------------------------------------
-- Add Flavor
--------------------------------------------------

local function AddFlavor(text)

    text = text or ""

    if math.random(100) <= 35 then
        local flavor = RandomFrom(Flavor)

        if flavor then
            text = text .. " " .. flavor
        end
    end

    return text
end

--------------------------------------------------
-- Generate Text
--------------------------------------------------

local function GenerateTrainerText()

    local title = GetNPCTitle()

    if title then

        local lower = string.lower(title)

        for key, pool in pairs(TitleSpecificText) do

            if lower:find(key) then

                local combined = {}

                for _, v in ipairs(pool) do
                    table.insert(combined, v)
                end

                local trainerType = DetectTrainerType()

                if trainerType and TrainerText[trainerType] then
                    for _, v in ipairs(TrainerText[trainerType]) do
                        table.insert(combined, v)
                    end
                end

                return AddFlavor(RandomFrom(combined))

            end

        end

    end

    local trainerType = DetectTrainerType()
    local pool = TrainerText[trainerType] or TrainerText.Default

    return AddFlavor(RandomFrom(pool))
end

--------------------------------------------------
-- Generate Replacement
--------------------------------------------------

local function GenerateReplacementText()

    BuildGossipCache()

    if GetNumTrainerServices and GetNumTrainerServices() > 0 then
        return GenerateTrainerText()
    end

    if HasGossipOption("train") then
        return GenerateTrainerText()
    end

    local trainerType = DetectTrainerType()

    if trainerType then
        return GenerateTrainerText()
    end

    if HasGossipOption("browse")
    or HasGossipOption("goods")
    or HasGossipOption("wares")
    or HasGossipOption("trade")
    or HasGossipOption("purchase")
    or HasGossipOption("vendor")
    then
        return AddFlavor(RandomFrom(VendorText))
    end

    if HasGossipOption("inn")
    or HasGossipOption("home")
    then
        return AddFlavor(RandomFrom(InnkeeperText))
    end

    if HasGossipOption("taxi")
    or HasGossipOption("flight")
    or HasGossipOption("fly")
    or HasGossipOption("ride")
    then
        return AddFlavor(RandomFrom(FlightMasterText))
    end

    if HasGossipOption("stable") then
        return AddFlavor(RandomFrom(StableMasterText))
    end

    if HasGossipOption("bank") then
        return AddFlavor(RandomFrom(BankerText))
    end

    local title = GetNPCTitle()

    if title then

        local lower = string.lower(title)

        for key, pool in pairs(TitleSpecificText) do

            if lower:find(key, 1, true) then
                return AddFlavor(RandomFrom(pool))
            end

        end

    end

    local availableQuests =
        GetNumAvailableQuests and GetNumAvailableQuests() or 0

    local activeQuests =
        GetNumActiveQuests and GetNumActiveQuests() or 0

    if availableQuests > 0 or activeQuests > 0 then
        return AddFlavor(RandomFrom(QuestNPCText))
    end

    return AddFlavor(RandomFrom(GenericNPCText))
end

--------------------------------------------------
-- Replacement Hook
--------------------------------------------------

local replacingText

hooksecurefunc(GossipGreetingText, "SetText", function(self, text)

    if replacingText then
        return
    end

    if text and text == BAD_TEXT then

        replacingText = true

        local replacement = GenerateReplacementText()

        if replacement then
            self:SetText(replacement)
        end

        replacingText = false

    end

end)