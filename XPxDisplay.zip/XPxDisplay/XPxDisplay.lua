local addon = CreateFrame("Frame")
local vipCheckPending = false

--------------------------------------------------
-- DATABASE
--------------------------------------------------

XPxDisplayDB = XPxDisplayDB or {}

local state = {
    blizzlike = false,
    isVIP = false,
}

local hoveringXPBar = false

--------------------------------------------------
-- HELPERS
--------------------------------------------------

local function GetXPText()
    if state.blizzlike then
        return "x1"
    end

    return state.isVIP and "x5" or "x3"
end

local function GetTooltipText()
    if state.blizzlike then
        return "Current setting: |cffffff00.blizzlike on|r (x1 xp)"
    end

    return state.isVIP
        and "Current setting: |cffffff00.blizzlike off|r  (x5 xp)"
        or "Current setting: |cffffff00.blizzlike off|r (x3 xp)"
end

--------------------------------------------------
-- XP BAR TEXT
--------------------------------------------------

local function UpdateXPBarText()
    if not MainMenuBarExpText then
        return
    end

    MainMenuBarExpText:Show()

    if hoveringXPBar then
        MainMenuBarExpText:SetText(
            string.format(
                "XP %d / %d (%s)",
                UnitXP("player"),
                UnitXPMax("player"),
                GetXPText()
            )
        )
    else
        MainMenuBarExpText:SetText("(" .. GetXPText() .. ")")
    end
end

--------------------------------------------------
-- STATE
--------------------------------------------------

local RefreshTooltip

local function SaveState()
    XPxDisplayDB.blizzlike = state.blizzlike

    local charKey = UnitName("player")

    XPxDisplayDB.VIPStatus = XPxDisplayDB.VIPStatus or {}
    XPxDisplayDB.VIPStatus[charKey] = state.isVIP

    UpdateXPBarText()
    RefreshTooltip()
end

local function LoadState()
    state.blizzlike = XPxDisplayDB.blizzlike and true or false

    local charKey = UnitName("player")

    if XPxDisplayDB.VIPStatus
        and XPxDisplayDB.VIPStatus[charKey] ~= nil then

        state.isVIP = XPxDisplayDB.VIPStatus[charKey]
    else
        state.isVIP = false
    end
end

--------------------------------------------------
-- TOOLTIP
--------------------------------------------------

local tooltipHooked = false

local function AddTooltipLine()
    if not GameTooltip:IsShown() then
        return
    end

    GameTooltip:AddLine(" ")
    GameTooltip:AddLine(
        "Click the XP bar to toggle the |cffffff00.blizzlike|r setting.",
        1, 1, 1
    )
    GameTooltip:AddLine(" ")
    GameTooltip:AddLine(GetTooltipText(), 1, 1, 1)

    GameTooltip:Show()
end

RefreshTooltip = function()
    if not MainMenuExpBar then
        return
    end

    if not MouseIsOver(MainMenuExpBar) then
        return
    end

    local onEnter = MainMenuExpBar:GetScript("OnEnter")

    if onEnter then
        GameTooltip:Hide()
        onEnter(MainMenuExpBar)
    end
end

--------------------------------------------------
-- XP BAR HOOKS
--------------------------------------------------

local function HookXPBar()
    if tooltipHooked then
        return
    end

    if not MainMenuExpBar then
        return
    end

    MainMenuExpBar:HookScript("OnEnter", function()
        hoveringXPBar = true
        UpdateXPBarText()
        AddTooltipLine()
    end)

    MainMenuExpBar:HookScript("OnLeave", function()
        hoveringXPBar = false
        UpdateXPBarText()
    end)

    MainMenuExpBar:HookScript("OnMouseDown", function()

        local charKey = UnitName("player")

        XPxDisplayDB.VIPStatus = XPxDisplayDB.VIPStatus or {}

        --------------------------------------------------
        -- UNKNOWN VIP STATUS
        --------------------------------------------------

        if XPxDisplayDB.VIPStatus[charKey] == nil then

            if not vipCheckPending then

                vipCheckPending = true

                SendChatMessage(".account", "SAY")
            end

            return
        end

        --------------------------------------------------
        -- TOGGLE BLIZZLIKE
        --------------------------------------------------

        if state.blizzlike then
            SendChatMessage(".blizzlike off", "SAY")
        else
            SendChatMessage(".blizzlike on", "SAY")
        end

    end)

    tooltipHooked = true
end

--------------------------------------------------
-- MESSAGE DETECTION
--------------------------------------------------

local function ProcessMessage(msg)
    if not msg then
        return
    end

    local lower = string.lower(msg)

    --------------------------------------------------
    -- BLIZZLIKE
    --------------------------------------------------

    if lower:find("x1 blizzlike") then

        state.blizzlike = true
        SaveState()

        return

    elseif lower:find("3x xp") then

        state.blizzlike = false
        SaveState()

        return
    end

    --------------------------------------------------
    -- VIP
    --------------------------------------------------

    if lower:find("your account level is: 1") then

        vipCheckPending = false

        local charKey = UnitName("player")

        state.isVIP = true

        XPxDisplayDB.VIPStatus = XPxDisplayDB.VIPStatus or {}
        XPxDisplayDB.VIPStatus[charKey] = true

        SaveState()

        print("|cffff0000XPxDisplay|r: VIP detected and saved for |cffff0000" .. charKey .. "|r")

        return

    elseif lower:find("your account level is: 0") then

        vipCheckPending = false

        local charKey = UnitName("player")

        state.isVIP = false

        XPxDisplayDB.VIPStatus = XPxDisplayDB.VIPStatus or {}
        XPxDisplayDB.VIPStatus[charKey] = false

        SaveState()

        print("|cffff0000XPxDisplay|r: Non-VIP detected and saved for |cffff0000" .. charKey .. "|r")

        return
    end
end

--------------------------------------------------
-- EVENTS
--------------------------------------------------

addon:RegisterEvent("PLAYER_LOGIN")
addon:RegisterEvent("PLAYER_XP_UPDATE")
addon:RegisterEvent("UPDATE_EXHAUSTION")
addon:RegisterEvent("CHAT_MSG_SYSTEM")
addon:RegisterEvent("UI_ERROR_MESSAGE")

addon:SetScript("OnEvent", function(self, event, arg1, arg2)

    if event == "PLAYER_LOGIN" then

        LoadState()
        HookXPBar()
        UpdateXPBarText()

        if TextStatusBar_UpdateTextString then
            hooksecurefunc("TextStatusBar_UpdateTextString", function(statusBar)
                if statusBar == MainMenuExpBar then
                    UpdateXPBarText()
                end
            end)
        end

        local charKey = UnitName("player")

        XPxDisplayDB.VIPStatus = XPxDisplayDB.VIPStatus or {}

        if XPxDisplayDB.VIPStatus[charKey] == nil then
            print("|cffff0000XPxDisplay|r: VIP status unknown. Please click the XP bar.")
        end

    elseif event == "PLAYER_XP_UPDATE" then

        UpdateXPBarText()

    elseif event == "UPDATE_EXHAUSTION" then

        UpdateXPBarText()

    elseif event == "CHAT_MSG_SYSTEM" then

        ProcessMessage(arg1)

    elseif event == "UI_ERROR_MESSAGE" then

        ProcessMessage(arg2)

    end
end)
