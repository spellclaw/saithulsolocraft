FlightPathFilterDB = FlightPathFilterDB or {}
local NEW_AREA_DISCOVERED_SOUND = 1519
local BuildOptionsUI
local GetCheckbox

-- =========================
-- NODE GROUPS
-- =========================

local NODE_GROUPS = {
    Alliance = {
        ["Eastern Kingdoms"] = {
            "Stormwind",
            "Sentinel Hill",
            "Lakeshire",
            "Darkshire",
            "Ironforge",
            "Thelsamar",
            "Menethil Harbor",
            "Refuge Pointe",
            "Aerie Peak",
            "Southshore",
            "Booty Bay",
            "Chillwind Camp",
            "Nethergarde Keep",
            "Morgan's Vigil",
            "Thorium Point",
            "Light's Hope Chapel"
        },
        ["Kalimdor"] = {
            "Rut'theran Village",
            "Auberdine",
            "Astranaar",
            "Talrendis Point",
            "Stonetalon Peak",
            "Talonbranch Glade",
            "Nijel's Point",
            "Theramore",
            "Ratchet",
            "Gadgetzan",
            "Marshal's Refuge",
            "Cenarion Hold",
            "Feathermoon",
            "Thalanaar",
            "Everlook",
            "Moonglade"
        }
    },
    Horde = {
        ["Eastern Kingdoms"] = {
            "Undercity",
            "The Sepulcher",
            "Tarren Mill",
            "Hammerfall",
            "Revantusk Village",
            "Kargath",
            "Stonard",
            "Grom'gol",
            "Booty Bay",
            "Flame Crest",
            "Light's Hope Chapel",
            "Thorium Point"            
        },
        ["Kalimdor"] = {
            "Orgrimmar",
            "Crossroads",
            "Ratchet",
            "Camp Taurajo",
            "Freewind Post",
            "Thunder Bluff",
            "Sun Rock Retreat",
            "Splintertree Post",
            "Brackenwall Village",
            "Shadowprey Village",
            "Valormok",
            "Bloodvenom Post",
            "Everlook",
            "Zoram'gar Outpost",
            "Camp Mojache",
            "Moonglade",
            "Cenarion Hold",
            "Gadgetzan",
            "Marshal's Refuge"
        }
    }
}

local function GetFaction()
    return UnitFactionGroup("player") or "Alliance"
end

local function GetGroupedNodes()
    return NODE_GROUPS[GetFaction()]
end

-- =========================
-- INIT DB
-- =========================

local function InitializeDB()
    if type(FlightPathFilterDB.enabled) ~= "boolean" then
        FlightPathFilterDB.enabled = true
    end

    FlightPathFilterDB.nodes = FlightPathFilterDB.nodes or {}

    for _, continents in pairs(NODE_GROUPS) do
        for _, list in pairs(continents) do
            for _, name in ipairs(list) do

                if not FlightPathFilterDB.nodes[name] then
                    FlightPathFilterDB.nodes[name] = {
                        enabled = false,
                        discovered = false
                    }
                end

                if FlightPathFilterDB.nodes[name].discovered == nil then
                    FlightPathFilterDB.nodes[name].discovered =
                        (FlightPathFilterDB.nodes[name].enabled == true)
                end

            end
        end
    end
end

-- =========================
-- MATCHING
-- =========================

local function GetNodeData(name)
    if not name then
        return nil
    end

    local short = string.match(name, "^[^,]+")

    return FlightPathFilterDB.nodes[short]
end

-- =========================
-- FILTERING
-- =========================

local function FilterTaxiNodes()

    for i = 1, NumTaxiNodes() do
        local btn = _G["TaxiButton"..i]

        if btn then

            local name = TaxiNodeName(i)
            local d = GetNodeData(name)
            local t = TaxiNodeGetType(i)

            -- Visiting a flight master automatically enables it
            if d and t == "CURRENT" then

                local newlyDiscovered = not d.discovered

                d.enabled = true
                d.discovered = true

                if newlyDiscovered then

                    -- Play discovery sound
                    PlaySound(NEW_AREA_DISCOVERED_SOUND)

                    -- Show yellow screen message
                    UIErrorsFrame:AddMessage(
                        "New flight path discovered!",
                        1.0, 0.82, 0.0,
                        1.0
                    )

                end
            end

            btn:Show()
            btn:EnableMouse(true)

            -- Addon disabled
            if FlightPathFilterDB.enabled ~= true then

                btn:SetAlpha(1)

            -- Current node
            elseif t == "CURRENT" then

                btn:SetAlpha(1)

            -- Enabled/tracked
            elseif d and d.enabled then

                btn:SetAlpha(1)

            -- Disabled/untracked
            else

                btn:SetAlpha(0.60)

            end
        end
    end
end

-- =========================
-- EVENTS
-- =========================

local frame = CreateFrame("Frame")

frame:RegisterEvent("ADDON_LOADED")
frame:RegisterEvent("TAXIMAP_OPENED")

local initialized = false

frame:SetScript("OnEvent", function(self, event, arg1)

    -- ADDON LOADED
    if event == "ADDON_LOADED" and not initialized then
        initialized = true

        -- Ensure we only run for this addon
        if arg1 == "FlightPathFilter" then
            InitializeDB()
            BuildOptionsUI()
        end
    end

    -- TAXI MAP OPENED
    if event == "TAXIMAP_OPENED" then
        -- Small delay to let Blizzard populate nodes
        C_Timer.After(0.1, function()
            FilterTaxiNodes()
        end)
    end
end)

-- =========================
-- UI
-- =========================

local panel=CreateFrame("Frame")
panel.name="FlightPathFilter"

local title=panel:CreateFontString(nil,"ARTWORK","GameFontNormalLarge")
title:SetPoint("TOPLEFT",16,-16)
title:SetText("FlightPathFilter")

local desc=panel:CreateFontString(nil,"ARTWORK","GameFontHighlightSmall")
desc:SetPoint("TOPLEFT",title,"BOTTOMLEFT",0,-6)
desc:SetWidth(500)
desc:SetJustifyH("LEFT")
desc:SetText(
    "Because all flight paths are unlocked on Solocraft, FlightPathFilter tracks which Flight Masters your character has visited. " ..
    "Discovered flight paths are highlighted while undiscovered destinations remain visible and available for travel."
)

local masterCheck=CreateFrame("CheckButton",nil,panel,"InterfaceOptionsCheckButtonTemplate")
masterCheck:SetPoint("TOPLEFT",desc,"BOTTOMLEFT",0,-16)
masterCheck.Text:SetText("Enable FPF")

local container=CreateFrame("Frame",nil,panel)
container:SetPoint("TOPLEFT",masterCheck,"BOTTOMLEFT",0,-20)
container:SetSize(640,420)

-- Section Headers (create once)
local ekHeader = container:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
ekHeader:SetPoint("TOPLEFT", 6, 0)
ekHeader:SetText("Eastern Kingdoms")

local kalHeader = container:CreateFontString(nil, "ARTWORK", "GameFontHighlight")

local checkboxes={}
local toggleButton
local discoveredButton

-- =========================
-- BUILD UI
-- =========================

BuildOptionsUI = function()

    local checkboxIndex = 0

    local groups = GetGroupedNodes()
    local ek = groups["Eastern Kingdoms"]
    local kal = groups["Kalimdor"]

    local y = 20

    local perCol = math.ceil(#ek / 3)

    for i, name in ipairs(ek) do

        local col = math.floor((i - 1) / perCol)
        local row = (i - 1) % perCol

        checkboxIndex = checkboxIndex + 1

        local cb = GetCheckbox(checkboxIndex)

        cb:SetPoint(
            "TOPLEFT",
            16 + col * 200,
            -y - row * 22
        )

        cb.nodeName = name
        cb.nodeData = FlightPathFilterDB.nodes[name]

        cb.Text:SetText(name)

    end

    y = y + (perCol * 22) + 20

    kalHeader:SetPoint("TOPLEFT", 6, -y)

    y = y + 20

    local perCol2 = math.ceil(#kal / 3)

    for i, name in ipairs(kal) do

        local col = math.floor((i - 1) / perCol2)
        local row = (i - 1) % perCol2

        checkboxIndex = checkboxIndex + 1

        local cb = GetCheckbox(checkboxIndex)

        cb:SetPoint(
            "TOPLEFT",
            16 + col * 200,
            -y - row * 22
        )

        cb.nodeName = name
        cb.nodeData = FlightPathFilterDB.nodes[name]

        cb.Text:SetText(name)

    end

end

-- =========================
-- RENDER HELPER
-- =========================

local function Checkbox_OnClick(self)

    local d = self.nodeData
    d.enabled = (self:GetChecked() == true)

    if d.enabled then
        PlaySound(SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_ON)
    else
        PlaySound(SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_OFF)
    end

    FilterTaxiNodes()

end

local function Checkbox_OnEnter(self)

    if FlightPathFilterDB.enabled == true then
        self.Text:SetTextColor(1, 0.82, 0)
    end

end

local function Checkbox_OnLeave(self)

    if FlightPathFilterDB.enabled ~= true then
        self.Text:SetTextColor(0.5, 0.5, 0.5)
    else
        self.Text:SetTextColor(1, 1, 1)
    end

end

GetCheckbox = function(index)

    if not checkboxes[index] then

        local cb = CreateFrame(
            "CheckButton",
            nil,
            container,
            "InterfaceOptionsCheckButtonTemplate"
        )

        cb:SetScript("OnClick", Checkbox_OnClick)
        cb:SetScript("OnEnter", Checkbox_OnEnter)
        cb:SetScript("OnLeave", Checkbox_OnLeave)

        checkboxes[index] = cb

    end

    return checkboxes[index]

end

-- =========================
-- TOGGLE TEXT
-- =========================

local function UpdateToggleButtonText()
    if not toggleButton then return end    

    if not FlightPathFilterDB.nodes then
        toggleButton:SetText("Select Discovered")
        return
    end

    -- Determine real state FIRST (always)
    local anyEnabled = false

    for _, data in pairs(FlightPathFilterDB.nodes) do
        if data.enabled then
            anyEnabled = true
            break
        end
    end

    -- Set correct label based on actual state
    toggleButton:SetText(anyEnabled and "Clear All" or "Select All")

    if FlightPathFilterDB.enabled ~= true then

        toggleButton:Disable()
        toggleButton:SetAlpha(0.5)

        discoveredButton:Disable()
        discoveredButton:SetAlpha(0.5)

    else

        toggleButton:Enable()
        toggleButton:SetAlpha(1)

        discoveredButton:Enable()
        discoveredButton:SetAlpha(1)

    end
end

-- =========================
-- UPDATE UI
-- =========================

local function RefreshOptionsUI()

    for _, cb in ipairs(checkboxes) do

        cb:SetChecked(cb.nodeData.enabled)

        if FlightPathFilterDB.enabled ~= true then

            cb:Disable()
            cb.Text:SetTextColor(0.5, 0.5, 0.5)

        else

            cb:Enable()
            cb.Text:SetTextColor(1, 1, 1)

        end

    end

    UpdateToggleButtonText()

end

-- =========================
-- MAIN TOGGLE
-- =========================

masterCheck:SetScript("OnClick",function(self)
    FlightPathFilterDB.enabled=(self:GetChecked()==true)

    if FlightPathFilterDB.enabled then
        PlaySound(SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_ON)
    else
        PlaySound(SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_OFF)
    end

    RefreshOptionsUI()
    FilterTaxiNodes()
end)

masterCheck:SetScript("OnEnter", function(self)
    self.Text:SetTextColor(1, 0.82, 0)
end)

masterCheck:SetScript("OnLeave", function(self)
    if FlightPathFilterDB.enabled == true then
        self.Text:SetTextColor(1, 1, 1)
    else
        self.Text:SetTextColor(0.5, 0.5, 0.5)
    end
end)

-- =========================
-- BUTTONS
-- =========================

toggleButton=CreateFrame("Button",nil,panel,"UIPanelButtonTemplate")
toggleButton:SetSize(150,25)

toggleButton:ClearAllPoints()
toggleButton:SetPoint("BOTTOMLEFT", 16, 16)

-- Tooltip refresh helper
local function RefreshToggleTooltip()
    if GameTooltip:IsOwned(toggleButton) then
        toggleButton:GetScript("OnEnter")(toggleButton)
    end
end

toggleButton:SetScript("OnEnter", function(self)

    GameTooltip:SetOwner(self, "ANCHOR_TOP")

    local anyEnabled = false

    for _, data in pairs(FlightPathFilterDB.nodes) do
        if data.enabled then
            anyEnabled = true
            break
        end
    end

    if anyEnabled then

        GameTooltip:SetText(
            "Clear All",
            1, 0.82, 0, 1
        )

        GameTooltip:AddLine(
            "Fades all flight paths.",
            1, 1, 1, true
        )

    else

        GameTooltip:SetText(
            "Select All",
            1, 0.82, 0, 1
        )

        GameTooltip:AddLine(
            "Highlights all flight paths.",
            1, 1, 1, true
        )

    end

    GameTooltip:AddLine(" ")

    GameTooltip:AddLine(
        "Does not reset this character's discovered flight paths.",
        0.75, 0.75, 0.75, true
    )

    GameTooltip:Show()

end)

toggleButton:SetScript("OnLeave", function()

    GameTooltip:Hide()

end)


toggleButton:SetScript("OnClick",function()
    PlaySound(SOUNDKIT.IG_MAINMENU_OPTION)
    local any=false
    for _,d in pairs(FlightPathFilterDB.nodes) do
        if d.enabled then any=true break end
    end

    local newState=not any
    for _,d in pairs(FlightPathFilterDB.nodes) do d.enabled=newState end

    RefreshOptionsUI()
    FilterTaxiNodes()

    RefreshToggleTooltip()
end)

discoveredButton = CreateFrame(
    "Button",
    nil,
    panel,
    "UIPanelButtonTemplate"
)

discoveredButton:SetSize(150, 25)
discoveredButton:SetPoint("LEFT", toggleButton, "RIGHT", 8, 0)
discoveredButton:SetText("Select Discovered")

--Discovered button tooltip
discoveredButton:SetScript("OnEnter", function(self)

    GameTooltip:SetOwner(self, "ANCHOR_TOP")
    GameTooltip:SetText(
        "Select Discovered",
        1, 0.82, 0, 1
    )

    GameTooltip:AddLine(
        "Highlights flight paths discovered by this character.",
        1, 1, 1, true
    )

    GameTooltip:AddLine(
        "Undiscovered flight paths remain visible and available for travel, but appear faded.",
        1, 1, 1, true
    )

    GameTooltip:Show()

end)

discoveredButton:SetScript("OnLeave", function()

    GameTooltip:Hide()

end)

--Discovered click function
discoveredButton:SetScript("OnClick", function()
    PlaySound(SOUNDKIT.IG_MAINMENU_OPTION)

    for _, data in pairs(FlightPathFilterDB.nodes) do
        data.enabled = (data.discovered == true)
    end

    RefreshOptionsUI()
    FilterTaxiNodes()

end)

-- =========================
-- SYNC FIX
-- =========================

local function SyncUI()
    masterCheck:SetChecked(FlightPathFilterDB.enabled==true)
    RefreshOptionsUI()
    UpdateToggleButtonText()
end

panel:SetScript("OnShow",function()
    SyncUI()
    C_Timer.After(0.05,SyncUI)
end)

hooksecurefunc("InterfaceOptionsFrame_OpenToCategory",function()
    C_Timer.After(0.05,SyncUI)
end)

InterfaceOptions_AddCategory(panel)